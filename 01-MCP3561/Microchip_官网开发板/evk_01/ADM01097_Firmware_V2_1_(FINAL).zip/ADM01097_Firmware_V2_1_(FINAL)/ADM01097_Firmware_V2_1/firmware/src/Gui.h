/*******************************************************************************
  Header file for Gui.c.

  Company:
    Microchip Technology Inc.

  File Name:
    Gui.h

  Summary:
    Header file for Gui.c.

  Description:
    Header file for Gui.c.

  Remarks:
    None.

*******************************************************************************/

/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef GUI_H
#define GUI_H

#include "definitions.h"
#include "MCP3564_Driver/MCP3564_DRV.h"
#include "app.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    extern "C" {

#endif
// DOM-IGNORE-END

typedef enum
{
    COMMAND_FREE,
    COMMAND_FILLING,
    COMMAND_PENDING,
    COMMAND_EXECUTING,
}CommandStatusType;

typedef enum
{
    GUI_INIT,
    GUI_WAIT_FOR_CMD,
    GUI_PROCESSING_CMD,
}GuiStateType;

typedef enum
{
    TX_IDLE,
    TX_FINISHED,
    TX_SENDING_ADCDATA,
    TX_SENDING_SHORTDATA,
    TX_NOTIFIED,
}GuiTransmitStatusType;

typedef enum
{
    ADC_IDLE,
    ADC_WRITE_REG,
    ADC_READ_REG,
    ADC_READ_DATA,
    ADC_SEND_DATA,
}ConverterStatusType;

typedef struct
{
   CommandStatusType CommandStatus;
   uint8_t CommandLength;
   uint8_t CommandData[50];
}CommandStorageType;
        
extern uint8_t GuiMainRerady;


void Gui_UartTxHandler(void);
void Gui_UartRxHandler(void);
void Gui_INT1Handler(void);
void Gui_Main(void);

        
// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    }
#endif
// DOM-IGNORE-END

#endif /* GUI_H */
