/*******************************************************************************
  Header file for MCP3564 driver.

  Company:
    Microchip Technology Inc.

  File Name:
    MCP3563_DRV.h

  Summary:
    Header file for MCP3564 driver.

  Description:
    This file Provides APIs and types to the user for integrating the MCP3564 
    in the application 

  Remarks:
    None.

*******************************************************************************/

/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef MCP3564_DRV_H
#define MCP3564_DRV_H

#include "MCP3564_DRV_Cfg.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    extern "C" {

#endif
// DOM-IGNORE-END

#define MCP3564_ADCDATA_ADDRESS 0x0
#define MCP3564_CONFIG0_ADDRESS 0x1
#define MCP3564_CONFIG1_ADDRESS 0x2
#define MCP3564_CONFIG2_ADDRESS 0x3
#define MCP3564_CONFIG3_ADDRESS 0x4       
#define MCP3564_IRQ_ADDRESS 0x5
#define MCP3564_MUX_ADDRESS 0x6
#define MCP3564_SCAN_ADDRESS 0x7
#define MCP3564_TIMER_ADDRESS 0x8
#define MCP3564_OFFSETCAL_ADDRESS 0x9
#define MCP3564_GAINCAL_ADDRESS 0xA
#define MCP3564_LOCK_ADDRESS 0xD
#define MCP3564_CRCCFG_ADDRESS 0xF        


typedef union
{
    struct
    {
        uint32_t DATA :24;
        uint8_t zero_padding : 8;
    }Format0;
    struct
    {
        uint8_t zero : 8;
        uint32_t DATA :24;
    }Format1;
    struct
    {
        uint32_t DATA :25;
        uint8_t  Sgn_padding :7;
    }Format2;
    struct
    {
        uint32_t Data : 25;
        uint8_t Sgn_padding : 3;
        uint8_t CH_ID : 4;
    }Format3;
    uint32_t Register;
}MCP3564_DRVAdcDataType;

        
extern MCP3564_DRVConfigType MCP3563Confg;

// *****************************************************************************
// *****************************************************************************
// Section: Interface Routines
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************

/*this function is used for initializing the main registers of the MCP3564 
using the configuration structures defined in MCP3564_DRV_Cfg.c*/
bool MCP3564_DRV_Init(uint8_t MCP3564_Id,MCP3564_DRVConfigType * ConfigStructPtr);

/*Function used for reading the CRCCFG register*/
bool MCP3564_DRV_ReadCRCCFG(uint8_t MCP3564_Id, uint16_t* value);

/*Function used for reading the ADC data register*/
bool MCP3564_DRV_ReadADCDATA(uint8_t MCP3564_Id, uint32_t* value);

/*Function used for reading the OFFSETCAL data register*/
bool MCP3564_DRV_ReadOFFSETCAL(uint8_t MCP3564_Id, uint32_t* value);

/*Function used for writing the OFFSETCAL data register*/
bool MCP3564_DRV_SetOFFSETCAL(uint8_t MCP3564_Id, uint32_t value);

/*Function used for reading the GAINCAL data register*/
bool MCP3564_DRV_ReadGAINCAL(uint8_t MCP3564_Id, uint32_t* value);

/*Function used for writing the GAINCAL data register*/
bool MCP3564_DRV_SetGAINCAL(uint8_t MCP3564_Id, uint32_t value);

/*Function used for reading the TIMER data register*/
bool MCP3564_DRV_ReadTIMER(uint8_t MCP3564_Id, uint32_t* value);

/*Function used for writing the TIMER data register*/
bool MCP3564_DRV_SetTIMER(uint8_t MCP3564_Id, uint32_t value);

/*Function used to lock access to the device registers (by 0 in the lock register)*/
bool MCP3564_DRV_Lock(uint8_t MCP3564_Id);

/*Function used to unlock access to the device registers (by 0xA5 in the lock register)*/
bool MCP3564_DRV_Unlock(uint8_t MCP3564_Id);


/*This function implements the fast command for starting or restarting the conversion*/
bool MCP3564_DRV_StartRestartConversion(uint8_t MCP3564_Id);

/*This function implements the fast command for transitioning to standby mode*/
bool MCP3564_DRV_GoToStandbyMode(uint8_t MCP3564_Id);

/*This function implements the fast command for transitioning to shut down mode*/
bool MCP3564_DRV_GoToShutDownMode(uint8_t MCP3564_Id);

/*This function implements the fast command for transitioning to full shut down mode*/
bool MCP3564_DRV_GoToFullShutDownMode(uint8_t MCP3564_Id);

/*This function implements the fast command for device reset*/
bool MCP3564_DRV_DeviceReset(uint8_t MCP3564_Id);

/*Function used to write a 8 bit register over SPI*/
bool MCP3564_DRV_WriteReg8(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint8_t data);

/*Function used to write a 24 bit register over SPI*/
bool MCP3564_DRV_WriteReg24(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t data);

/*Function used to write a 32 bit register over SPI*/
bool MCP3564_DRV_WriteReg32(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t data);

/*Function used to read a 8 bit register over SPI*/
bool MCP3564_DRV_ReadReg8(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint8_t * data);

/*Function used to read a 16 bit register over SPI*/
bool MCP3564_DRV_ReadReg16(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint16_t * data);

/*Function used to read a 24 bit register over SPI*/
bool MCP3564_DRV_ReadReg24(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t * data);

/*Function used to read a 32 bit register over SPI*/
bool MCP3564_DRV_ReadReg32(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t * data);


// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    }
#endif
// DOM-IGNORE-END

#endif /* MCP3564_DRV_H */
