/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "lcd_c0216ciz_internal.h"
#include "definitions.h"
#include "bsp_i2c.h"


#define LCD_C0216CIZ_SLAVE_ADDRESS     0x7C

#define LCD_C0216CIZ_CONTROL_COMMMAND  0x80
#define LCD_C0216CIZ_CONTROL_DATA      0x60

static uint8_t lcd_c0216ciz_i2c_send_buf[2] = {0, 0};

void lcd_c0216ciz_hw_turn_on()
{
}

void lcd_c0216ciz_hw_turn_off()
{
}

uint8_t lcd_c0216ciz_hw_i2c_get_lock()
{
  return bsp_i2c2_get_lock();
}

void lcd_c0216ciz_hw_i2c_release_lock()
{
  bsp_i2c2_release_lock();
}

uint8_t lcd_c0216ciz_hw_ready()
{
  return (!bsp_i2c2_is_busy());
}

void lcd_c0216ciz_hw_send_command(const uint8_t byte)
{
  lcd_c0216ciz_i2c_send_buf[0] = LCD_C0216CIZ_CONTROL_COMMMAND;
  lcd_c0216ciz_i2c_send_buf[1] = byte;
  bsp_i2c2_write(LCD_C0216CIZ_SLAVE_ADDRESS, 2, lcd_c0216ciz_i2c_send_buf);
}

void lcd_c0216ciz_hw_send_data(const uint8_t byte)
{
  lcd_c0216ciz_i2c_send_buf[0] = LCD_C0216CIZ_CONTROL_DATA;
  lcd_c0216ciz_i2c_send_buf[1] = byte;
  bsp_i2c2_write(LCD_C0216CIZ_SLAVE_ADDRESS, 2, lcd_c0216ciz_i2c_send_buf);
}