/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "bsp_i2c.h"
#include <assert.h>


static volatile uint8_t i2c2_locked = 0;
static volatile uint8_t i2c2_buffer[3];
static volatile uint8_t i2c2_operation_len;
static volatile uint16_t i2c2_count;
static volatile uint8_t *i2c2_operation_buf;

static enum
{
  I2C_OPERATION_NONE = 0,
  I2C_OPERATION_READ = 1,
  I2C_OPERATION_WRITE = 2,
  I2C_OPERATION_READ_MEM = 3,
  I2C_OPERATION_WRITE_MEM = 4,
} i2c2_operation_type;

static enum
{
  I2C_STATE_START = 0,
  I2C_STATE_WRITE_ADDR,
  I2C_STATE_WRITE_REGISTER,

  I2C_STATE_READ_MEM_ACK,
  I2C_STATE_READ_MEM_RESTART,
  I2C_STATE_READ_MEM_WRITE_ADDR,

  I2C_STATE_WRITE_BUFFER,

  I2C_STATE_READ_BUFFER,
  I2C_STATE_READ_BUFFER_ACKNACK,

  I2C_STATE_STOP,
} i2c2_state;


void __attribute__ ((interrupt,  vector(_I2C_2_VECTOR))) _I2C2MInterrupt(void)
{
  bsp_i2c2_isr();
  IFS1bits.I2C2MIF = 0;
}

void bsp_init_i2c2(const uint8_t mode)
{
  I2C2CONbits.I2CSIDL = 1;
  I2C2CONbits.A10M = 0;
  I2C2CONbits.DISSLW = 0;
  I2C2CONbits.SMEN = 0;
  I2C2CONbits.ACKDT = 0;
  
  I2C2BRG = FCY_PLL / (2 * I2C_FREQUENCY) - 2;

  i2c2_locked = 0;
  i2c2_operation_type = I2C_OPERATION_NONE;

  IFS1bits.I2C2MIF = 0;
  IPC8bits.I2C2IP = 7;
  IEC1bits.I2C2MIE = 1;
}

void set_init()
{
  IFS1bits.I2C2MIF = 1;
}

uint8_t bsp_i2c2_is_busy()
{
  return (i2c2_operation_type != I2C_OPERATION_NONE);
}

uint8_t bsp_i2c2_get_lock()
{
  if(i2c2_locked == 0)
  {
    i2c2_locked = 1;
    I2C2CONbits.I2CEN = 1;
    return 1;
  }
  else
    return 0;
}

void bsp_i2c2_release_lock()
{
  I2C2CONbits.I2CEN = 0;
  i2c2_locked = 0;
}

uint8_t bsp_i2c2_is_locked()
{
  return i2c2_locked;
}

void bsp_i2c2_read_mem(const uint8_t i2c_addr, const uint8_t reg, const uint8_t len, uint8_t *buffer)
{
  i2c2_buffer[0] = i2c_addr;            //write
  i2c2_buffer[1] = reg;
  i2c2_buffer[2] = i2c_addr + 1;        //read
  i2c2_operation_buf = buffer;
  i2c2_operation_len = len;
  i2c2_operation_type = I2C_OPERATION_READ_MEM;
  i2c2_state = I2C_STATE_START;
  I2C2CONbits.SEN = 1;
}

void bsp_i2c2_write_mem(const uint8_t i2c_addr, const uint8_t reg, const uint8_t len, const uint8_t *buffer)
{
  i2c2_buffer[0] = i2c_addr;            //write
  i2c2_buffer[1] = reg;
  i2c2_operation_buf = (uint8_t*)buffer;
  i2c2_operation_len = len;
  i2c2_operation_type = I2C_OPERATION_WRITE_MEM;
  i2c2_state = I2C_STATE_START;
  I2C2CONbits.SEN = 1;
}

void bsp_i2c2_read(const uint8_t i2c_addr, const uint8_t len, uint8_t *buffer)
{
  i2c2_buffer[0] = i2c_addr + 1;        //read
  i2c2_operation_buf = buffer;
  i2c2_operation_len = len;
  i2c2_operation_type = I2C_OPERATION_READ;
  i2c2_state = I2C_STATE_START;
  I2C2CONbits.SEN = 1;
}

void bsp_i2c2_write(const uint8_t i2c_addr, const uint8_t len, const uint8_t *buffer)
{
  i2c2_buffer[0] = i2c_addr;            //write
  i2c2_operation_buf = (uint8_t*)buffer;
  i2c2_operation_len = len;
  i2c2_operation_type = I2C_OPERATION_WRITE;
  i2c2_state = I2C_STATE_START;
  I2C2CONbits.SEN = 1;
}

void bsp_i2c2_isr()
{
  switch(i2c2_state)
  {
    case I2C_STATE_START:               //finished start
      i2c2_state = I2C_STATE_WRITE_ADDR;
      I2C2TRN = i2c2_buffer[0];
      i2c2_count = 0;
    break;

    case I2C_STATE_WRITE_ADDR:          //finished writing address (either with write or read)
      if(i2c2_operation_type == I2C_OPERATION_WRITE)
      {
        if(i2c2_operation_len == 0)
        {
          I2C2CONbits.PEN = 1;
          i2c2_state = I2C_STATE_STOP;
        }
        else
        {
          I2C2TRN = i2c2_operation_buf[0];
          i2c2_count++;
          i2c2_state = I2C_STATE_WRITE_BUFFER;
        }
      }
      else
      if(i2c2_operation_type == I2C_OPERATION_READ)
      {
        I2C2CONbits.RCEN = 1;
        i2c2_state = I2C_STATE_READ_BUFFER;
      }
      else
      if((i2c2_operation_type == I2C_OPERATION_WRITE_MEM) || (i2c2_operation_type == I2C_OPERATION_READ_MEM))
      {
        I2C2TRN = i2c2_buffer[1];
        i2c2_state = I2C_STATE_WRITE_REGISTER;
      }
    break;

    case I2C_STATE_WRITE_REGISTER:          //finished writing register address for mem operation
      if(i2c2_operation_type == I2C_OPERATION_WRITE_MEM)
      {
        if(i2c2_operation_len == 0)
        {
          I2C2CONbits.PEN = 1;
          i2c2_state = I2C_STATE_STOP;
        }
        else
        {
          I2C2TRN = i2c2_operation_buf[0];
          i2c2_count++;
          i2c2_state = I2C_STATE_WRITE_BUFFER;
        }
      }
      else
      if(i2c2_operation_type == I2C_OPERATION_READ_MEM)
      {
        I2C2CONbits.ACKDT = 0;
        I2C2CONbits.ACKEN = 1;
        i2c2_state = I2C_STATE_READ_MEM_ACK;
      }
    break;

    case I2C_STATE_READ_MEM_ACK:
        I2C2CONbits.RSEN = 1;
        i2c2_state = I2C_STATE_READ_MEM_RESTART;
    break;

    case I2C_STATE_READ_MEM_RESTART:
        I2C2TRN = i2c2_buffer[2];           
        i2c2_state = I2C_STATE_READ_MEM_WRITE_ADDR;
    break;

    case I2C_STATE_READ_MEM_WRITE_ADDR:
        I2C2CONbits.RCEN = 1;
        i2c2_state = I2C_STATE_READ_BUFFER;
    break;

    case I2C_STATE_WRITE_BUFFER:
      if(i2c2_count >= i2c2_operation_len)
      {
        I2C2CONbits.PEN = 1;
        i2c2_state = I2C_STATE_STOP;
      }
      else
      {
        I2C2TRN = i2c2_operation_buf[i2c2_count];
        i2c2_count++;
      }
    break;

    case I2C_STATE_READ_BUFFER:
      i2c2_operation_buf[i2c2_count] = I2C2RCV;
      i2c2_count++;
      if(i2c2_count >= i2c2_operation_len)
      {
        I2C2CONbits.ACKDT = 1;
        I2C2CONbits.ACKEN = 1;
      }
      else
      {
        I2C2CONbits.ACKDT = 0;
        I2C2CONbits.ACKEN = 1;
      }
      i2c2_state = I2C_STATE_READ_BUFFER_ACKNACK;
    break;

    case I2C_STATE_READ_BUFFER_ACKNACK:
      if(i2c2_count >= i2c2_operation_len)
      {
        I2C2CONbits.PEN = 1;
        i2c2_state = I2C_STATE_STOP;
      }
      else
      {
        I2C2CONbits.RCEN = 1;
        i2c2_state = I2C_STATE_READ_BUFFER;
      }
    break;

    case I2C_STATE_STOP:
      i2c2_operation_type = I2C_OPERATION_NONE;
    break;

    default:
      assert(0);
    break;
  }
}