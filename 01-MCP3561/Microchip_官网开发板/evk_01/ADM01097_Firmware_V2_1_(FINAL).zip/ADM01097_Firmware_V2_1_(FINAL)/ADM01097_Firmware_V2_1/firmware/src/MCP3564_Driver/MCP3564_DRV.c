/*******************************************************************************
  MCP3564_DRV API implementation.

  Company
    Microchip Technology Inc.

  File Name
    MCP3564_DRV.c

  Summary
    MCP3564_DRV API implementation.

  Description
    This file implements the all the functions of the MCP3564 driver.

*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include "MCP3564_DRV.h"
#include "MCP3564_DRV_Cfg.h"


#define MCP3564_DRV_WRITE_COMMAND 0x2
#define MCP3564_DRV_READ_COMMAND 0x3
#define MCP3564_DRV_FAST_COMMAND 0x0

#define MCP3564_DRV_CONV_START_CMD 0xA
#define MCP3564_DRV_STANDBY_CMD 0xB
#define MCP3564_DRV_SHUTDOWN_CMD 0xC
#define MCP3564_DRV_FULLSHUTDOWN_CMD 0xD
#define MCP3564_DRV_DEV_RESET_CMD 0xE

/*Function used to write a 8 bit register over SPI*/
bool MCP3564_DRV_WriteReg8(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint8_t data)
{
    uint8_t WriteBuffer[2];
    uint8_t ReadBuffer[2];
    bool SpiReturn = 0;
   
    WriteBuffer[0] = MCP3564_DRV_WRITE_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = data;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 2,ReadBuffer, 2);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}

/*Function used to write a 16 bit register over SPI*/
bool MCP3564_DRV_WriteReg16(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint16_t data)
{
    uint8_t WriteBuffer[3];
    uint8_t ReadBuffer[3];
    bool SpiReturn = 0;
    
    WriteBuffer[0] = MCP3564_DRV_WRITE_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = (data&0xFF00)>>8;
    WriteBuffer[2] = (data&0xFF)>>0;

    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 3,ReadBuffer, 3);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    return SpiReturn;
}

/*Function used to write a 24 bit register over SPI*/
bool MCP3564_DRV_WriteReg24(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t data)
{
    uint8_t WriteBuffer[4];
    uint8_t ReadBuffer[4];
    bool SpiReturn = 0;
    
    WriteBuffer[0] = MCP3564_DRV_WRITE_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = (data&0xFF0000)>>16;
    WriteBuffer[2] = (data&0xFF00)>>8;
    WriteBuffer[3] = (data&0xFF)>>0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 4,ReadBuffer, 4);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    return SpiReturn;
}

/*Function used to write a 32 bit register over SPI*/
bool MCP3564_DRV_WriteReg32(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t data)
{
    uint8_t WriteBuffer[5];
    uint8_t ReadBuffer[5];
    bool SpiReturn = 0;
    
    WriteBuffer[0] = MCP3564_DRV_WRITE_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = (data&0xFF000000)>>24;
    WriteBuffer[2] = (data&0xFF0000)>>16;
    WriteBuffer[3] = (data&0xFF00)>>8;
    WriteBuffer[3] = (data&0xFF)>>0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 5,ReadBuffer, 5);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    return SpiReturn;
}

/*Function used to read a 8 bit register over SPI*/
bool MCP3564_DRV_ReadReg8(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint8_t * data)
{
    bool SpiReturn;
    uint8_t WriteBuffer[2];
    uint8_t ReadBuffer[2];
   
    WriteBuffer[0] = MCP3564_DRV_READ_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = 0x0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 2,ReadBuffer, 2);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    *data = ReadBuffer[1];
    return SpiReturn;
}

/*Function used to read a 16 bit register over SPI*/
bool MCP3564_DRV_ReadReg16(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint16_t * data)
{
    bool SpiReturn;
    uint8_t WriteBuffer[3];
    uint8_t ReadBuffer[3];
   
    WriteBuffer[0] = MCP3564_DRV_READ_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = 0x0;
    WriteBuffer[2] = 0x0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 3,ReadBuffer, 3);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    *data  = 0;
    *data = ReadBuffer[2] | ((uint16_t)ReadBuffer[1]<<8) ;    
    return SpiReturn;
}

/*Function used to read a 24 bit register over SPI*/
bool MCP3564_DRV_ReadReg24(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t * data)
{
    bool SpiReturn;
    uint8_t WriteBuffer[4];
    uint8_t ReadBuffer[4];
    
    WriteBuffer[0] = MCP3564_DRV_READ_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = 0x0;
    WriteBuffer[2] = 0x0;
    WriteBuffer[3] = 0x0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 4,ReadBuffer, 4);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    *data  = 0;
    *data = ReadBuffer[3] | ((uint32_t)ReadBuffer[2]<<8) | ((uint32_t)ReadBuffer[1]<<16);
    
    return SpiReturn;
}

/*Function used to read a 32 bit register over SPI*/
bool MCP3564_DRV_ReadReg32(uint8_t MCP3564_Id, MCP3564_DRV_DeviceAddressType deviceAddress,uint8_t address,uint32_t * data)
{
    bool SpiReturn;
    uint8_t WriteBuffer[5];
    uint8_t ReadBuffer[5];
    
    WriteBuffer[0] = MCP3564_DRV_READ_COMMAND|
                     ((address&0xF)<<2)|
                     (deviceAddress<<6);
    WriteBuffer[1] = 0x0;
    WriteBuffer[2] = 0x0;
    WriteBuffer[3] = 0x0;
    WriteBuffer[4] = 0x0;
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn = SPI2_WriteRead(WriteBuffer, 5,ReadBuffer, 5);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    *data  = 0;
    *data = ReadBuffer[4] | ((uint32_t)ReadBuffer[3]<<8) | ((uint32_t)ReadBuffer[2]<<16)| ((uint32_t)ReadBuffer[1]<<24);
    return SpiReturn;
}

/*this function is used for initializing the main registers of the MCP3564 
using the configuration structures defined in MCP3564_DRV_Cfg.c*/
bool MCP3564_DRV_Init(uint8_t MCP3564_Id,MCP3564_DRVConfigType * ConfigStructPtr)
{
    bool RetValue = 1;
    
    /*initialize the CONFIG0 register*/    
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_CONFIG0_ADDRESS,
                             ConfigStructPtr->CONFIG0.R))
    {
        RetValue = 0;
    }
    /*initialize the CONFIG1 register*/
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_CONFIG1_ADDRESS,
                             ConfigStructPtr->CONFIG1.R))
    {
        RetValue = 0;
    }
    /*initialize the CONFIG2 register*/
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_CONFIG2_ADDRESS,
                             ConfigStructPtr->CONFIG2.R|0x3))
    {
        RetValue = 0;
    }
    /*initialize the CONFIG3 register*/
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_CONFIG3_ADDRESS,
                             ConfigStructPtr->CONFIG3.R))
    {
        RetValue = 0;
    }
    /*initialize the IRQ register*/
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_IRQ_ADDRESS,
                             ConfigStructPtr->IRQ.R))
    {
        RetValue = 0;
    }
    /*initialize the MUX register*/
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_MUX_ADDRESS,
                             ConfigStructPtr->MUX.R))
    {
        RetValue = 0;
    }
    /*initialize the SCAN register*/
    if(!MCP3564_DRV_WriteReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_SCAN_ADDRESS,
                             ConfigStructPtr->SCAN.R))
    {
        RetValue = 0;
    }
    /*initialize the TIMER register*/
    if(!MCP3564_DRV_WriteReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_TIMER_ADDRESS,
                             ConfigStructPtr->TIMER.R))
    {
        RetValue = 0;
    }
    return RetValue;
}

/*This function implements the fast command for starting or restarting the conversion*/
bool MCP3564_DRV_StartRestartConversion(uint8_t MCP3564_Id)
{
    uint8_t WriteBuffer[1];
    uint8_t ReadBuffer[1];
    bool SpiReturn;
   
    WriteBuffer[0] = MCP3564_DRV_FAST_COMMAND|
                     ((MCP3564_DRV_CONV_START_CMD&0xF)<<2)|
                     (MCP3563_DeviceAddressList[MCP3564_Id]<<6);
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 1,ReadBuffer, 1);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}
/*This function implements the fast command for transitioning to standby mode*/
bool MCP3564_DRV_GoToStandbyMode(uint8_t MCP3564_Id)
{
    uint8_t WriteBuffer[1];
    uint8_t ReadBuffer[1];
    bool SpiReturn;
   
    WriteBuffer[0] = MCP3564_DRV_FAST_COMMAND|
                     ((MCP3564_DRV_STANDBY_CMD&0xF)<<2)|
                     (MCP3563_DeviceAddressList[MCP3564_Id]<<6);
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 1,ReadBuffer, 1);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}
/*This function implements the fast command for transitioning to shut down mode*/
bool MCP3564_DRV_GoToShutDownMode(uint8_t MCP3564_Id)
{
    uint8_t WriteBuffer[1];
    uint8_t ReadBuffer[1];
    bool SpiReturn;
   
    WriteBuffer[0] = MCP3564_DRV_FAST_COMMAND|
                     ((MCP3564_DRV_SHUTDOWN_CMD&0xF)<<2)|
                     (MCP3563_DeviceAddressList[MCP3564_Id]<<6);
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 1,ReadBuffer, 1);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}
/*This function implements the fast command for transitioning to full shut down mode*/
bool MCP3564_DRV_GoToFullShutDownMode(uint8_t MCP3564_Id)
{
    uint8_t WriteBuffer[1];
    uint8_t ReadBuffer[1];
    bool SpiReturn;
   
    WriteBuffer[0] = MCP3564_DRV_FAST_COMMAND|
                     ((MCP3564_DRV_FULLSHUTDOWN_CMD&0xF)<<2)|
                     (MCP3563_DeviceAddressList[MCP3564_Id]<<6);
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 1,ReadBuffer, 1);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}

/*This function implements the fast command for device reset*/
bool MCP3564_DRV_DeviceReset(uint8_t MCP3564_Id)
{
    uint8_t WriteBuffer[1];
    uint8_t ReadBuffer[1];
    bool SpiReturn;
   
    WriteBuffer[0] = MCP3564_DRV_FAST_COMMAND|
                     ((MCP3564_DRV_DEV_RESET_CMD&0xF)<<2)|
                     (MCP3563_DeviceAddressList[MCP3564_Id]<<6);
    
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_ACTIVE_VALUE);
    SpiReturn =  SPI2_WriteRead(WriteBuffer, 1,ReadBuffer, 1);
    MCP3564_SetGPIO(MCP3563_DeviceCSPinList[MCP3564_Id],MCP3564_CS_INACTIVE_VALUE);
    
    return SpiReturn;
}

/*Function used for reading the CRCCFG register*/
bool MCP3564_DRV_ReadCRCCFG(uint8_t MCP3564_Id, uint16_t* value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_ReadReg16(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_CRCCFG_ADDRESS,
                             value))
    {
        RetValue = 0;
    }
    return RetValue;
}
/*Function used for reading the ADC data register*/
bool MCP3564_DRV_ReadADCDATA(uint8_t MCP3564_Id, uint32_t* value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_ReadReg32(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_ADCDATA_ADDRESS,
                             value))
    {
        RetValue = 0;
    }
    return RetValue;
}

/*Function used for reading the OFFSETCAL data register*/
bool MCP3564_DRV_ReadOFFSETCAL(uint8_t MCP3564_Id, uint32_t* value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_ReadReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_OFFSETCAL_ADDRESS,
                             value))
    {
        RetValue = 0;
    }
    return RetValue;
}
/*Function used for writing the OFFSETCAL data register*/
bool MCP3564_DRV_SetOFFSETCAL(uint8_t MCP3564_Id, uint32_t value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_WriteReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_OFFSETCAL_ADDRESS,
                             value))
    {
        RetValue = 0;
    }   
    return RetValue;
}
/*Function used for reading the GAINCAL data register*/
bool MCP3564_DRV_ReadGAINCAL(uint8_t MCP3564_Id, uint32_t* value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_ReadReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_GAINCAL_ADDRESS,
                             value))
    {
        RetValue = 0;
    }
    return RetValue;
}
/*Function used for writing the GAINCAL data register*/
bool MCP3564_DRV_SetGAINCAL(uint8_t MCP3564_Id, uint32_t value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_WriteReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_GAINCAL_ADDRESS,
                             value))
    {
        RetValue = 0;
    }  
    return RetValue;
}
/*Function used for reading the TIMER data register*/
bool MCP3564_DRV_ReadTIMER(uint8_t MCP3564_Id, uint32_t* value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_ReadReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_TIMER_ADDRESS,
                             value))
    {
        RetValue = 0;
    }
    return RetValue;

}
/*Function used for writing the TIMER data register*/
bool MCP3564_DRV_SetTIMER(uint8_t MCP3564_Id, uint32_t value)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_WriteReg24(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_TIMER_ADDRESS,
                             value))
    {
        RetValue = 0;
    }  
    return RetValue;
}

/*Function used to lock access to the device registers (by 0 in the lock register)*/
bool MCP3564_DRV_Lock(uint8_t MCP3564_Id)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_LOCK_ADDRESS,
                             0))
    {
        RetValue = 0;
    }  
    return RetValue;
}
/*Function used to unlock access to the device registers (by 0xA5 in the lock register)*/
bool MCP3564_DRV_Unlock(uint8_t MCP3564_Id)
{
    bool RetValue = 1;
    if(!MCP3564_DRV_WriteReg8(MCP3564_Id,
                             MCP3563_DeviceAddressList[MCP3564_Id],
                             MCP3564_LOCK_ADDRESS,
                             0xA5))
    {
        RetValue = 0;
    }      
    return RetValue;
}
