/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "lcd_c0216ciz.h"
#include "lcd_c0216ciz_internal.h"
#include <string.h>
#include <assert.h>

#define LCD_C0216CIZ_TOTAL_LINES     2
#define LCD_C0216CIZ_CHARS_PER_LINE  16

static enum
{
  LCD_C0216CIZ_STATE_OFF = 0,
  LCD_C0216CIZ_STATE_TURN_ON,
  LCD_C0216CIZ_STATE_IDLE,
  LCD_C0216CIZ_STATE_PRINT,
  LCD_C0216CIZ_STATE_TURN_OFF,
} lcd_c0216ciz_state;

static uint8_t lcd_c0216ciz_in_state;
static uint8_t lcd_must_turn_off;
static uint16_t lcd_c0216ciz_timeout;
static uint8_t lcd_c0216ciz_print_current_line;
static uint8_t lcd_c0216ciz_print_msg_fresh_data;
static char lcd_c0216ciz_print_msg[LCD_C0216CIZ_TOTAL_LINES][LCD_C0216CIZ_CHARS_PER_LINE];

void lcd_c0216ciz_on_tick_isr()
{
  if(lcd_c0216ciz_timeout)
    lcd_c0216ciz_timeout--;
}

void lcd_c0216ciz_init()
{
  uint8_t i;
  uint8_t j;

  lcd_c0216ciz_state = LCD_C0216CIZ_STATE_OFF;
  lcd_c0216ciz_in_state = 0;
  lcd_must_turn_off = 0;
  lcd_c0216ciz_timeout = 0;
  lcd_c0216ciz_print_current_line = 0;

  lcd_c0216ciz_print_msg_fresh_data = 0;

  for(i = 0; i < LCD_C0216CIZ_TOTAL_LINES; i++)
  {
    for(j = 0; j < LCD_C0216CIZ_CHARS_PER_LINE; j++)
      lcd_c0216ciz_print_msg[i][j] = ' ';
  }
}

void lcd_c0216ciz_main_loop()
{
  static uint8_t current_send_char;
  switch(lcd_c0216ciz_state)
  {
    case LCD_C0216CIZ_STATE_OFF:
    {
      //do nothing
    } break;

    case LCD_C0216CIZ_STATE_TURN_ON:
    {
      switch(lcd_c0216ciz_in_state)
      {
        case 0:
          if(lcd_c0216ciz_hw_i2c_get_lock())
            lcd_c0216ciz_in_state++;
          break;

        case 1:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x38);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 2:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x39);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 3:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x14);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 4:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x78);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 5:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x5D);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 6:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x6D);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 7:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_timeout = 2;   
            lcd_c0216ciz_in_state++;
          }
        break;

        case 8:
          if(lcd_c0216ciz_timeout == 0)
          {
            lcd_c0216ciz_hw_send_command(0x0C);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 9:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_command(0x01);
            lcd_c0216ciz_in_state++;
          }
        break;

        case 10:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_in_state = 0;
            lcd_c0216ciz_state = LCD_C0216CIZ_STATE_IDLE;
            lcd_c0216ciz_hw_i2c_release_lock();
          }
        break;

        default:
          assert(0);
          break;
        }
    } break;

    case LCD_C0216CIZ_STATE_IDLE:
    {
      //does nothing until requested to print
      if(lcd_c0216ciz_print_msg_fresh_data)
      {
        lcd_c0216ciz_state = LCD_C0216CIZ_STATE_PRINT;
        lcd_c0216ciz_in_state = 0;
        return;
      }
      else
      if(lcd_must_turn_off)
      {
        lcd_must_turn_off = 0;
        lcd_c0216ciz_state = LCD_C0216CIZ_STATE_TURN_OFF;
        lcd_c0216ciz_in_state = 0;
      } 
    } break;

    case LCD_C0216CIZ_STATE_PRINT:
    {
      switch(lcd_c0216ciz_in_state)
      {
        case 0:
          if(lcd_c0216ciz_hw_i2c_get_lock())
            lcd_c0216ciz_in_state++;
          break;

        case 1:
          if(lcd_c0216ciz_hw_ready())
          {
            switch(lcd_c0216ciz_print_current_line)
            {
              case 0:
                lcd_c0216ciz_hw_send_command(0x80);    
                break;

              case 1:
                lcd_c0216ciz_hw_send_command(0xC0);
                break;

              default:
                assert(0);
                break;
            }

            lcd_c0216ciz_in_state++;
            current_send_char = 0;
          }
        break;

        case 2:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_hw_send_data(lcd_c0216ciz_print_msg[lcd_c0216ciz_print_current_line][current_send_char]);
            current_send_char++;
            if(current_send_char >= LCD_C0216CIZ_CHARS_PER_LINE)
              lcd_c0216ciz_in_state++;
          }
        break;

        case 3:
          if(lcd_c0216ciz_hw_ready())
          {
            lcd_c0216ciz_in_state = 1;
            lcd_c0216ciz_print_current_line++;
            if(lcd_c0216ciz_print_current_line == LCD_C0216CIZ_TOTAL_LINES)
            {
              lcd_c0216ciz_print_current_line = 0;
              lcd_c0216ciz_state = LCD_C0216CIZ_STATE_IDLE;
              lcd_c0216ciz_hw_i2c_release_lock();
              lcd_c0216ciz_print_msg_fresh_data = 0;
            }
          }
        break;

        default:
          assert(0);
        break;
      }
    } break;

    case LCD_C0216CIZ_STATE_TURN_OFF:
      lcd_c0216ciz_hw_turn_off();
      lcd_c0216ciz_state = LCD_C0216CIZ_STATE_OFF;
      lcd_c0216ciz_in_state = 0;
    break;

    default:
      assert(0);
    break;
  }
}

void lcd_c0216ciz_turn_on()
{
  if(lcd_c0216ciz_state == LCD_C0216CIZ_STATE_OFF)
  {
    lcd_c0216ciz_hw_turn_on();
    lcd_c0216ciz_state = LCD_C0216CIZ_STATE_TURN_ON;
    lcd_c0216ciz_in_state = 0;
  }
}

void lcd_c0216ciz_turn_off()
{
  lcd_must_turn_off = 1;
}

void lcd_c0216ciz_print_line(const uint8_t line, const char *msg)
{
  uint8_t i;

  //assert(msg != NULL);

  lcd_c0216ciz_print_msg_fresh_data = 1;
  i = 0;
  while(i < LCD_C0216CIZ_CHARS_PER_LINE)
  {
    if(msg[i] != 0)
    {
      lcd_c0216ciz_print_msg[line][i] = msg[i];
      i++;
    }
    else
    while(i < LCD_C0216CIZ_CHARS_PER_LINE)
    {
      lcd_c0216ciz_print_msg[line][i] = ' ';
      i++;
    }
  }
}

uint8_t lcd_c0216ciz_is_on()
{
  return (lcd_c0216ciz_state != LCD_C0216CIZ_STATE_OFF);
}

uint8_t lcd_c0216ciz_is_ready()
{
  return (lcd_c0216ciz_state == LCD_C0216CIZ_STATE_IDLE);
}