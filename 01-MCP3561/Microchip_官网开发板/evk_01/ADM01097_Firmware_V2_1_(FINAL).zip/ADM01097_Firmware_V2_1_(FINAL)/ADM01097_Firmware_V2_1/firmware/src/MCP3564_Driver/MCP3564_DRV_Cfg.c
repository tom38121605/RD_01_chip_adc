/*******************************************************************************
  MCP3564_DRV Configuration implementation.

  Company
    Microchip Technology Inc.

  File Name
    MCP3564_DRV.c

  Summary
    MCP3564_DRV configuration implementation.

  Description
    This file implements the configuration structure used to initialize the  MCP3564 driver.

*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include "MCP3564_DRV_Cfg.h"


/*this array defines the pins used as Chip Select for each MCP3563 device*/
const uint32_t MCP3563_DeviceCSPinList [MCP3564_NUMBER_OF_DEVICES] =
{
    (uint32_t)GPIO_PIN_RG9,//CS pin for device 0
};

/*this array defines the device ID for each MCP3563 device (can be determined by the markings on the chip)*/
const MCP3564_DRV_DeviceAddressType MCP3563_DeviceAddressList [MCP3564_NUMBER_OF_DEVICES] = 
{
    MCP3564_DRV_DEVICE_ADDRESS_1,//address for device 0
};


/*configuration structure that contains the main parameters of a MCP3563 device
it can be used as a parameter for MCP3564_DRV_Init function
multiple copies of this configuration can be created to store and use different configurations at runtime*/        
MCP3564_DRVConfigType MCP3563Confg =
{
/*------------CONFIG0----------*/

    /*Full Shutdown Mode Enable
    These bits are writable but have no effect except that they force Full Shutdown mode when they are
    set to 00 and when all other CONFIG0 bits are set to 0. */ 
   .CONFIG0.B.CONFIG0 = 0,

    /*Clock Selection
    3 = Internal clock is selected and AMCLK is present on the analog master clock output pin
    2 = Internal clock is selected and no clock output is present on the CLK pin
    1 = External digital clock
    0 = External digital clock (default)*/
   .CONFIG0.B.CLK_SEL = 0,   
   
    /*Current Source/Sink Selection Bits for Sensor Bias (source on VIN+/sink on VIN-)
    3 = 15 uA is applied to the ADC inputs
    2 = 3.7 uA is applied to the ADC inputs
    1 = 0.9 uA is applied to the ADC inputs
    0 = No current source is applied to the ADC inputs (default) */
   .CONFIG0.B.CS_SEL = 0,
   
    /*ADC Operating Mode Selection
    3 = ADC Conversion mode
    2 = ADC Standby mode
    1 = ADC Shutdown mode
    0 = ADC Shutdown mode (default)*/   
   .CONFIG0.B.ADC_MODE = 3,
/*------------CONFIG1----------*/
    /*PRE: Pre scaler Value Selection for AMCLK
    3 = AMCLK = MCLK/8
    2 = AMCLK = MCLK/4
    1 = AMCLK = MCLK/2
    0 = AMCLK = MCLK (default)*/
    .CONFIG1.B.PRE = 0,
   
    /*OSR: Oversampling Ratio for Delta-Sigma A/D Conversion
    15 = OSR: 98304
    14 = OSR: 81920
    13 = OSR: 49152
    12 = OSR: 40960
    11 = OSR: 24576   
    10 = OSR: 20480
    9 = OSR: 16384
    8 = OSR: 8192
    7 = OSR: 4096
    6 = OSR: 2048
    5 = OSR: 1024
    4 = OSR: 512
    3 = OSR: 256 (default)
    2 = OSR: 128
    1 = OSR: 64
    0 = OSR: 32*/
    .CONFIG1.B.OSR = 3,
   
/*------------CONFIG2----------*/
   /*BOOST: ADC Bias Current Selection
    3 = ADC channel has current x 2
    2 = ADC channel has current x 1 (default)
    1 = ADC channel has current x 0.66
    0 = ADC channel has current x 0.5*/
    .CONFIG2.B.BOOST = 2,
    
   /*GAIN: ADC Gain Selection
    7 = Gain is x64 (x16 analog, x4 digital)
    6 = Gain is x32 (x16 analog, x2 digital)
    5 = Gain is x16
    4 = Gain is x8
    3 = Gain is x4
    2 = Gain is x2
    1 = Gain is x1 (default)
    0 = Gain is x1/3*/
    .CONFIG2.B.GAIN = 1,
   
    /*AZ_MUX: Auto-Zeroing MUX Setting
    1 = ADC auto-zeroing algorithm is enabled. This setting multiplies the conversion time by two and
    does not allow Continuous Conversion mode operation (which is then replaced by a series of
    consecutive One-Shot mode conversions).
    0 = Analog input multiplexer auto-zeroing algorithm is disabled (default)*/
    .CONFIG2.B.AZ_MUX = 0,
   
/*------------CONFIG3----------*/
   /*CONV_MODE[1:0]: Conversion Mode Selection
    3 = Continuous Conversion mode or continuous conversion cycle in SCAN mode
    2 = One-shot conversion or one-shot cycle in SCAN mode. It sets ADC_MODE[1:0] to ?10? (standby) at
         the end of the conversion or at the end of the conversion cycle in SCAN mode.
    0or1 = One-shot conversion or one-shot cycle in SCAN mode. It sets ADC_MODE[1:0] to ?0x? (ADC
         Shutdown) at the end of the conversion or at the end of the conversion cycle in SCAN mode (default).*/
    .CONFIG3.B.CONV_MODE = 3,
   
    /*DATA_FORMAT[1:0]: ADC Output Data Format Selection
    3 = 32-bit (25-bit right justified data + Channel ID): CHID[3:0] + SGN extension (4 bits) + 24-bit ADC
        data. It allows overrange with the SGN extension.
    2 = 32-bit (25-bit right justified data): SGN extension (8-bit) + 24-bit ADC data. It allows overrange with
        the SGN extension.
    1 = 32-bit (24-bit left justified data): 24-bit ADC data + 0x00 (8-bit). It does not allow overrange (ADC
        code locked to 0xFFFFFF or 0x800000).
    0 = 24-bit (default ADC coding): 24-bit ADC data. It does not allow overrange (ADC code locked to
        0xFFFFFF or 0x800000).*/
    .CONFIG3.B.DATA_FORMAT = 3,
   
    /*CRC_FORMAT: CRC Checksum Format Selection on Read Communications
    (it does not affect CRCCFG coding)
    1 = 32-bit wide (CRC-16 followed by 16 zeros)
    0 = 16-bit wide (CRC-16 only) (default)*/
    .CONFIG3.B.CRC_FORMAT = 0,
   
    /*EN_CRCCOM: CRC Checksum Selection on Read Communications
     (it does not affect CRCCFG calculations)
    1 = CRC on communications enabled
    0 = CRC on communications disabled (default)*/
    .CONFIG3.B.EN_CRCCOM  = 0,
   
    /*EN_OFFCAL: Enable Digital Offset Calibration
    1 = Enabled
    0 = Disabled (default)*/
    .CONFIG3.B.EN_OFFCAL = 0,
   
    /*EN_GAINCAL: Enable Digital Gain Calibration
    1 = Enabled
    0 = Disabled (default)*/
    .CONFIG3.B.EN_GAINCAL = 0,
   
/*------------IRQ-------------*/    
    /*DR_STATUS: Data Ready Status Flag
    1 = ADCDATA has not been updated since last reading or last Reset (default)
    0 = New ADCDATA ready for reading*/
    .IRQ.B.DR_STATUS = 0,
   
    /*CRCCFG_STATUS: CRC Error Status Flag Bit for Internal Registers
    1 = CRC error has not occurred for the Configuration registers (default)
    0 = CRC error has occurred for the Configuration registers*/
    .IRQ.B.CRCCFG_STATUS = 0,
   
    /*POR_STATUS: POR Status Flag
    1 = POR has not occurred since the last reading (default)
    0 = POR has occurred since the last reading*/
    .IRQ.B.POR_STATUS = 0,
   
    /*IRQ_MODE[1:0]: Configuration for the IRQ/MDAT Pin
    IRQ_MODE[1]: IRQ/MDAT Selection
    1 = MDAT output is selected. Only POR and CRC interrupts can be present on this pin and take priority
    over the MDAT output.
    0 = IRQ output is selected. All interrupts can appear on the IRQ/MDAT pin.
    IRQ_MODE[0]: IRQ Pin Inactive State Selection
    1 = The Inactive state is logic high (does not require a pull-up resistor to DVDD)
    0 = The Inactive state is high-Z (requires a pull-up resistor to DVDD) (default)*/
    .IRQ.B.IRQ_MODE = 0,
   
    /*EN_FASTCMD: Enable Fast Commands in the COMMAND Byte
    1 = Fast commands are enabled (default)
    0 = Fast commands are disabled*/
    .IRQ.B.EN_FASTCMD = 1,
   
    /*EN_STP: Enable Conversion Start Interrupt Output
    1 = Enabled (default)
    0 = Disabled*/
    .IRQ.B.EN_STP = 1,
   
/*------------MUX-------------*/
    /*MUX_VIN+ Input Selection(2,3)
    15 = Internal VCM
    14 = Internal Temperature Sensor Diode M (Temp Diode M)(1)
    13 = Internal Temperature Sensor Diode P (Temp Diode P)(1)
    12 = REFIN-
    11 = REFIN+
    10 = Reserved (do not use)
    9 = AVDD
    8 = AGND
    7 = CH7
    6 = CH6
    5 = CH5
    4 = CH4
    3 = CH3
    2 = CH2
    1 = CH1
    0 = CH0 (default)*/
    .MUX.B.MUX_VIN_PLUS = 0,
   
    /*MUX_VIN- Input Selection(2,3)
    15 = Internal VCM
    14 = Internal Temperature Sensor Diode M (Temp Diode M)(1)
    13 = Internal Temperature Sensor Diode P (Temp Diode P)(1)
    12 = REFIN-
    11 = REFIN+
    10 = Reserved (do not use)
    9 = AVDD
    8 = AGND
    7 = CH7
    6 = CH6
    5 = CH5
    4 = CH4
    3 = CH3
    2 = CH2
    1 = CH1 (default)
    0 = CH0*/
    .MUX.B.MUX_VIN_MINUS = 1,
   
/*-----------SCAN-------------*/   
    /*DLY[2:0]: Delay Time (TDLY_SCAN) Between Each Conversion During a Scan Cycle
    7 = 512 * DMCLK
    6 = 256 * DMCLK
    5 = 128 * DMCLK
    4 = 64 * DMCLK
    3 = 32 * DMCLK
    2 = 16 * DMCLK
    1 = 8 * DMCLK
    0 = 0: No delay (default)*/
    .SCAN.B.DLY = 0, 
   
    /*Scan Channel Selection(see Table 5-14 in datasheet for a complete description)*/
    .SCAN.B.SCAN_SE_CH = 3,
    .SCAN.B.SCAN_DIFF_CH = 0,
    .SCAN.B.TEMP = 0,
    .SCAN.B.AVDD = 0,
    .SCAN.B.VCM = 0,
    .SCAN.B.OFFSET = 0,
/*-----------TIMER-------------*/
    /*TIMER[23:0]: Selection Bits for the Time Interval (TTIMER_SCAN) Between Two Consecutive Scan Cycles
    (when CONV_MODE[1:0] = 11):
    0xFFFFFF: TTIMER_SCAN = 16777215 * DMCLK periods
    0xFFFFFE: TTIMER_SCAN = 16777214 * DMCLK periods
    ...
    0x000002: TTIMER_SCAN = 2 * DMCLK periods
    0x000001: TTIMER_SCAN = 1 * DMCLK periods
    0x000000: TTIMER_SCAN = 0 (No delay) ? default*/
    .TIMER.B.TIMER = 0,
};

