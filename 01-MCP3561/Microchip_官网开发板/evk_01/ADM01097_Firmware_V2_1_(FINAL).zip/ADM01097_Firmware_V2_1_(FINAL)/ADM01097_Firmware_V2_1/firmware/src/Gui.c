/*******************************************************************************
  Gui communication implementation.

  Company
    Microchip Technology Inc.

  File Name
    Gui.c

  Summary
    Gui communication implementation.

  Description
    This file implements the all the functions for communicating with the GUI.

*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "Gui.h"
#include "MCP3564_Driver/MCP3564_DRV.h"
#include "mcp41010/mcp41010.h"

#define ADC_TX_BUFF_SIZE (ADC_NUMBER_OF_SAMPLES-1)*22+43
#define ADC_NUMBER_OF_SAMPLES 2048
#define GUI_CURRENT_COMMAND_NONE 0xFF

/*array that stores the framed adc data in ASCII format that can be sent over UART to the gui application*/
uint8_t __attribute__((coherent)) AdcDataTXBuffer[ADC_TX_BUFF_SIZE];

/*Temporary buffer that stores data in ASCII format before sending it over UART (used by all commands except the read start command)*/
uint8_t __attribute__((coherent)) GuiShortTXBuffer[100];

/*Array that stores the adc data read from the first channel*/
volatile uint32_t __attribute__((coherent)) CH0DataArray[ADC_NUMBER_OF_SAMPLES+4];

/*Array that stores the adc data read from the first channel*/
volatile uint32_t __attribute__((coherent)) CH1DataArray[ADC_NUMBER_OF_SAMPLES+4];

/*number of samples read for the first channel in this round of conversions*/
volatile uint32_t CH0SampleCounter = 0;

/*number of samples read for the second channel in this round of conversions*/
volatile uint32_t CH1SampleCounter = 0;

/*flag which indicates that CH0DataArray is full*/
volatile uint8_t CH0AquisitionComplete = 0;

/*flag which indicates that CH1DataArray is full*/
volatile uint8_t CH1AquisitionComplete = 0;

/*array of 3 structures that stores up to 3 command frames received from the GUI application*/
CommandStorageType __attribute__((coherent)) GuiCommandBuffer[3];

/*variable that specifies which one of the 3 command structures should be processed*/
volatile uint8_t GuiCrtCmdBuff = 0;

/*flag that indicates that the GuiMain function is ready to be called periodically*/
uint8_t GuiMainRerady = 1;

/*variable that controls the GUI state machine*/
volatile GuiStateType GuiState = GUI_INIT;

/*variable that specifies which command is currently being processed*/
volatile uint8_t GuiCurrentCommandProc = GUI_CURRENT_COMMAND_NONE;

/*variable that indicates if there are messages queued for transmission*/
volatile GuiTransmitStatusType GuiTransmitStatus = TX_IDLE;

/*Variable used to send adc data 100 characters at a time*/
volatile uint32_t GuiAdcDataSendIndex = 0;

/*variable that specifies the current operation of the ADC data acquisition process*/
volatile ConverterStatusType ConverterStatus = ADC_IDLE;

/*array that stores hexadecimal register values received from the gui application to be written to the MCP3564*/
uint32_t __attribute__((coherent)) DecodedWriteCommand[15];

/*array that contains the hexadecimal values read from the MCP3564 registers*/
uint32_t __attribute__((coherent)) DecodedReadResponse[15];

/*framed register values in ascii format to be sent to the GUI application*/
uint8_t __attribute__((coherent)) EncodedReadResponse[100];

/*number of ascii characters to be sent to the GUI as a response to a register read request*/
volatile uint8_t EncodedResonseLenght = 0;

/*Converter speed received from the GUI application as part of the register write command*/
volatile uint32_t ConvertorSpeed = 4;

/*Reference source selection received from the GUI application as part of the register write command*/
volatile uint32_t ReferenceMux = 0;

/*Digital potentiometer value received from the GUI application as part of the register write command*/
volatile uint32_t DigiPotValue = 0;

/*variables that specifies whether to add the read data in CH0DataArray or CH0DataArray 
(the value toggles between 0 and 1 after each read interrupt)*/
volatile uint8_t GuiChannelNumber = 0;

/*function used to start populating a command in a free command buffer*/
void GuiNewCommand(uint8_t character)
{
    if(character == 'i'||
       character == 'v'||
       character == 'W'||
       character == 'R'||
       character == 't'||
       character == 's'||
       character == 'p')
    {
        if(GuiCommandBuffer[0].CommandStatus == COMMAND_FREE)
        {
            GuiCrtCmdBuff = 0;
        }
        else if(GuiCommandBuffer[1].CommandStatus == COMMAND_FREE)
        {
            GuiCrtCmdBuff = 1;
        }
        else if(GuiCommandBuffer[2].CommandStatus == COMMAND_FREE)
        {
            GuiCrtCmdBuff = 2;
        }
        GuiCommandBuffer[GuiCrtCmdBuff].CommandLength = 0;
        GuiCommandBuffer[GuiCrtCmdBuff].CommandStatus = COMMAND_FILLING;
        GuiCommandBuffer[GuiCrtCmdBuff].CommandData[0] = character;
        GuiCommandBuffer[GuiCrtCmdBuff].CommandLength++;  
    }
 
}

/*function used to add a character to the current command buffer*/
void GuiAddToCommand(uint8_t character)
{
    GuiCommandBuffer[GuiCrtCmdBuff].CommandData[GuiCommandBuffer[GuiCrtCmdBuff].CommandLength] = character;
    if(character=='\r')
    {
        GuiCommandBuffer[GuiCrtCmdBuff].CommandStatus = COMMAND_PENDING;
    }
    else
    {
        GuiCommandBuffer[GuiCrtCmdBuff].CommandLength++;
    }
}

/*function used to delete the content of a command buffer and make it free for filling in a new command*/
void GuiClearCommand(uint8_t commandNumber)
{
    uint8_t i = 0;
    
    for(i=0;i<50;i++)
    {
        GuiCommandBuffer[commandNumber].CommandData[i] = 0;
    }
    GuiCommandBuffer[commandNumber].CommandLength = 0;
    GuiCommandBuffer[GuiCrtCmdBuff].CommandStatus = COMMAND_FREE;
    GuiCurrentCommandProc = GUI_CURRENT_COMMAND_NONE;
}


/*function called from the uart RX callback*/
void Gui_UartRxHandler(void)
{
    
    if(GuiCommandBuffer[GuiCrtCmdBuff].CommandStatus != COMMAND_FILLING)
    {
        GuiNewCommand(ReceivedCharacter);
    }
    else
    {
        GuiAddToCommand(ReceivedCharacter);
    }
    
}


/*function used to read the adc result from the MCP3564 once the external interrupt is triggered*/
void Gui_AquireAdcData(void)
{
    MCP3564_DRVAdcDataType Data;
    static uint8_t ChOld = 0;
    MCP3564_DRV_ReadADCDATA(0,&Data.Register);
    
    if(Data.Format3.CH_ID > ChOld)
    {
        GuiChannelNumber = 0;
    }
    else
    {
        GuiChannelNumber = 1;
    }
    ChOld = Data.Format3.CH_ID;
    if(0 == GuiChannelNumber)
    {
        CH0DataArray[CH0SampleCounter] = Data.Register;
        if(CH0SampleCounter <ADC_NUMBER_OF_SAMPLES-1+4)
        {
            CH0SampleCounter++;
        }
        else
        {
            CH0SampleCounter = 0;
            CH0AquisitionComplete = 1;
        }
    }
    
    if(1 == GuiChannelNumber)
    {

        CH1DataArray[CH1SampleCounter] = Data.Register;
        if(CH1SampleCounter <ADC_NUMBER_OF_SAMPLES-1+4)
        {
            CH1SampleCounter++;
        }
        else
        {
            CH1SampleCounter = 0;
            CH1AquisitionComplete = 1;
        }
    }
}


/*function used to send the conversion results to the GUI application via UART in 100 byte portions
this function is called once at the start of the send operation, and repeatedly until all the data is sent*/
void GuiSendAdcData(void)
{
   if(GuiAdcDataSendIndex == 0 && GuiTransmitStatus == TX_SENDING_ADCDATA)
   {
       UART2_Write(&AdcDataTXBuffer[0],100);
       GuiAdcDataSendIndex = GuiAdcDataSendIndex + 100;
   }
   else if(0<GuiAdcDataSendIndex && GuiAdcDataSendIndex+100 <ADC_TX_BUFF_SIZE )
   {
       UART2_Write(&AdcDataTXBuffer[GuiAdcDataSendIndex],100);
       GuiAdcDataSendIndex = GuiAdcDataSendIndex + 100;
       GuiTransmitStatus = TX_SENDING_ADCDATA;
   }
   else if(0<GuiAdcDataSendIndex && GuiAdcDataSendIndex+100 >=ADC_TX_BUFF_SIZE)
   {
       UART2_Write(&AdcDataTXBuffer[GuiAdcDataSendIndex],ADC_TX_BUFF_SIZE-GuiAdcDataSendIndex);
       GuiAdcDataSendIndex = 0;
       GuiTransmitStatus = TX_SENDING_ADCDATA;
   }
   else if(GuiAdcDataSendIndex == 0 && GuiTransmitStatus == TX_NOTIFIED)
   {
       GuiTransmitStatus = TX_FINISHED;
   }
}

/*function used to convert a variable length string of ascii character digits into a number*/
void GuiAsciiToDec(uint8_t * sAddress,uint32_t * dAddress, uint8_t length)
{
   uint8_t TempChars[10];
   uint8_t i;
   uint8_t j;
   uint32_t Value = 0;
   uint32_t PowerOfTen;
   
   PowerOfTen = 1;
    for(i=0;i<length;i++)
    {
        TempChars[length-1-i] = sAddress[i]-'0';
        
        PowerOfTen = 1;
        for(j=0;j<length-1-i;j++)
        {
            PowerOfTen = PowerOfTen*10;
        }
        Value = Value + (TempChars[length-1-i]*PowerOfTen);
    }
    *dAddress = Value;
}

/*function used to convert a ascii character digit into a number*/
static inline uint8_t Gui_CharToAscii(uint8_t character)
{
    return character +'0';
}

/*function used to convert a number into a 10 digit string of ascii characters*/
static inline void Gui_DecimalToAscii(uint32_t value, uint8_t* destString)
{
    uint8_t BCDValue[10] = {0};
    
    while(value>999999999)
    {
        value = value-1000000000;
        BCDValue[9]++;
    }
    while(value>99999999)
    {
        value = value-100000000;
        BCDValue[8]++;
    }
    while(value>9999999)
    {
        value = value-10000000;
        BCDValue[7]++;
    }    
    while(value>999999)
    {
        value = value-1000000;
        BCDValue[6]++;
    }   
    while(value>99999)
    {
        value = value-100000;
        BCDValue[5]++;
    }
    while(value>9999)
    {
        value = value-10000;
        BCDValue[4]++;
    }
    while(value>999)
    {
        value = value-1000;
        BCDValue[3]++;
    }
    while(value>99)
    {
        value = value-100;
        BCDValue[2]++;
    }
    while(value>9)
    {
        value = value-10;
        BCDValue[1]++;
    }
    
    BCDValue[0] = value;
    
    destString[0] = Gui_CharToAscii(BCDValue[0]);
    destString[1] = Gui_CharToAscii(BCDValue[1]);
    destString[2] = Gui_CharToAscii(BCDValue[2]);
    destString[3] = Gui_CharToAscii(BCDValue[3]);
    destString[4] = Gui_CharToAscii(BCDValue[4]);
    destString[5] = Gui_CharToAscii(BCDValue[5]);
    destString[6] = Gui_CharToAscii(BCDValue[6]);
    destString[7] = Gui_CharToAscii(BCDValue[7]);
    destString[8] = Gui_CharToAscii(BCDValue[8]);
    destString[9] = Gui_CharToAscii(BCDValue[9]);
    

}


/*function that resets the timer values so they can be used for the next round of conversions*/
void Gui_ResetAqTime(void)
{
    TMR5=0;
    TMR4=0;
}

    volatile uint32_t TimeValue;

/*function that reads the 32bit timer to determine the duration of the conversion round in microseconds*/
uint32_t Gui_GetAqTme(void)
{  
    
    uint32_t CounterVlaue;

    CounterVlaue = (TMR5<<16)+TMR4;
    
    TimeValue = CounterVlaue/10000;
    TimeValue = TimeValue * 125;
    
    return TimeValue;
    
}

/*function used to convert the adc result values into framed ascii strings that can be sent to the GUI application*/
void Gui_PrepareAdcData(void)
{
    uint32_t PrepareDataIndex = 0;
    uint8_t ConvertedNumberCH0[10];
    uint8_t ConvertedNumberCH1[10];
    uint8_t ConvertedTime[10];
    
    AdcDataTXBuffer[0]='!';

    while(PrepareDataIndex < ADC_NUMBER_OF_SAMPLES)
    {
        Gui_DecimalToAscii(CH0DataArray[PrepareDataIndex+1],ConvertedNumberCH0);
        Gui_DecimalToAscii(CH1DataArray[PrepareDataIndex+1],ConvertedNumberCH1);
        AdcDataTXBuffer[PrepareDataIndex*22+1] = ConvertedNumberCH0[9];
        AdcDataTXBuffer[PrepareDataIndex*22+2] = ConvertedNumberCH0[8];
        AdcDataTXBuffer[PrepareDataIndex*22+3] = ConvertedNumberCH0[7];
        AdcDataTXBuffer[PrepareDataIndex*22+4] = ConvertedNumberCH0[6];
        AdcDataTXBuffer[PrepareDataIndex*22+5] = ConvertedNumberCH0[5];
        AdcDataTXBuffer[PrepareDataIndex*22+6] = ConvertedNumberCH0[4];
        AdcDataTXBuffer[PrepareDataIndex*22+7] = ConvertedNumberCH0[3];
        AdcDataTXBuffer[PrepareDataIndex*22+8] = ConvertedNumberCH0[2];
        AdcDataTXBuffer[PrepareDataIndex*22+9] = ConvertedNumberCH0[1];
        AdcDataTXBuffer[PrepareDataIndex*22+10] = ConvertedNumberCH0[0];
        AdcDataTXBuffer[PrepareDataIndex*22+11] = ',';
        AdcDataTXBuffer[PrepareDataIndex*22+12] = ConvertedNumberCH1[9];
        AdcDataTXBuffer[PrepareDataIndex*22+13] = ConvertedNumberCH1[8];
        AdcDataTXBuffer[PrepareDataIndex*22+14] = ConvertedNumberCH1[7];
        AdcDataTXBuffer[PrepareDataIndex*22+15] = ConvertedNumberCH1[6];
        AdcDataTXBuffer[PrepareDataIndex*22+16] = ConvertedNumberCH1[5];
        AdcDataTXBuffer[PrepareDataIndex*22+17] = ConvertedNumberCH1[4];
        AdcDataTXBuffer[PrepareDataIndex*22+18] = ConvertedNumberCH1[3];
        AdcDataTXBuffer[PrepareDataIndex*22+19] = ConvertedNumberCH1[2];
        AdcDataTXBuffer[PrepareDataIndex*22+20] = ConvertedNumberCH1[1];
        AdcDataTXBuffer[PrepareDataIndex*22+21] = ConvertedNumberCH1[0];
        AdcDataTXBuffer[PrepareDataIndex*22+22] = ';';
        PrepareDataIndex++;
    }
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+22] = ':';
    Gui_DecimalToAscii(Gui_GetAqTme(),ConvertedTime);
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+23] = ConvertedTime[9];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+24] = ConvertedTime[8];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+25] = ConvertedTime[7];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+26] = ConvertedTime[6];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+27] = ConvertedTime[5];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+28] = ConvertedTime[4];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+29] = ConvertedTime[3];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+30] = ConvertedTime[2];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+31] = ConvertedTime[1];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+32] = ConvertedTime[0];
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+33] = ',';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+34] = '2';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+35] = '5';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+36] = '.';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+37] = '0';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+38] = '0';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+39] = '0';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+40] = '0';
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+41] = 0;
    AdcDataTXBuffer[(ADC_NUMBER_OF_SAMPLES-1)*22+42] = '\r';
    
    
}


/*function called from the external interrupt notification when a conversion is complete*/
void Gui_INT1Handler(void)
{
    
    if(!(CH0AquisitionComplete&&CH1AquisitionComplete))
    {
        Gui_AquireAdcData();
    }
    else
    {
        EVIC_ExternalInterruptDisable( EXTERNAL_INT_1 );
        TMR4_Stop();
    }
}


/*function called from the UART TX notification*/
void Gui_UartTxHandler(void)
{
    if(GuiTransmitStatus == TX_SENDING_SHORTDATA)
    {
        GuiTransmitStatus = TX_NOTIFIED;
    }
    else if(GuiTransmitStatus == TX_SENDING_ADCDATA)
    {
        GuiTransmitStatus = TX_NOTIFIED;
        GuiSendAdcData();
    }
}

/*function used to initialize the AdcDataTXBuffer*/
void GuiInit(void)
{
    uint32_t i;
    
    for(i=0;i<ADC_TX_BUFF_SIZE;i++)
    {
        AdcDataTXBuffer[i]=0;
    }
}

/*function that checks if there is any stop conversion request from the GUI application*/
uint8_t GuiCheckForPCommand(void)
{
    uint8_t i;
    uint8_t PCommandFound = 0;
    for(i=0;i<3;i++)
    {
        if(GuiCommandBuffer[i].CommandStatus == COMMAND_PENDING &&
           GuiCommandBuffer[i].CommandData[0]=='p')
        {
            PCommandFound = 1;
        }
    
    }
    
    return PCommandFound;
}

/*function that checks if there is any command waiting to be processed*/
void GuiCheckCommand(void)
{
    if(GuiCommandBuffer[0].CommandStatus == COMMAND_PENDING &&
        GuiCurrentCommandProc ==  GUI_CURRENT_COMMAND_NONE)
    {
        GuiCurrentCommandProc = 0;
        GuiState = GUI_PROCESSING_CMD;
    }
    else if(GuiCommandBuffer[1].CommandStatus == COMMAND_PENDING &&
            GuiCurrentCommandProc ==  GUI_CURRENT_COMMAND_NONE)
    {
        GuiCurrentCommandProc = 1;
        GuiState = GUI_PROCESSING_CMD;
    }
    else if(GuiCommandBuffer[2].CommandStatus == COMMAND_PENDING &&
            GuiCurrentCommandProc ==  GUI_CURRENT_COMMAND_NONE)
    {
        GuiCurrentCommandProc = 2;
        GuiState = GUI_PROCESSING_CMD;
    }
    else
    {
        GuiCurrentCommandProc = GUI_CURRENT_COMMAND_NONE;
        GuiState = GUI_WAIT_FOR_CMD;
    }
    
}

/*function used to execute the i command*/
void ProcessCommand_i(void)
{
    GuiShortTXBuffer[0]='i';
    GuiShortTXBuffer[1]='A';
    GuiShortTXBuffer[2]='D';
    GuiShortTXBuffer[3]='M';
    GuiShortTXBuffer[4]='0';
    GuiShortTXBuffer[5]='1';
    GuiShortTXBuffer[6]='0';
    GuiShortTXBuffer[7]='9';
    GuiShortTXBuffer[8]='7';
    GuiShortTXBuffer[9]='\r';
    GuiTransmitStatus = TX_SENDING_SHORTDATA;
    UART2_Write(&GuiShortTXBuffer[0],10);
    while(GuiTransmitStatus != TX_NOTIFIED)
    {
    ;
    }
    GuiTransmitStatus = TX_IDLE;
    GuiClearCommand(GuiCurrentCommandProc);
}

/*function used to execute the v command*/
void ProcessCommand_v(void)
{
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    if(GuiTransmitStatus == TX_IDLE)
    {
        GuiShortTXBuffer[0]='v';
        GuiShortTXBuffer[1]='1';
        GuiShortTXBuffer[2]='.';
        GuiShortTXBuffer[3]='0';
        GuiShortTXBuffer[4]='.';
        GuiShortTXBuffer[5]='1';
        GuiShortTXBuffer[6]='\r';
        GuiTransmitStatus = TX_SENDING_SHORTDATA;
        UART2_Write(&GuiShortTXBuffer[0],7);
        while(GuiTransmitStatus !=TX_NOTIFIED)
        {
        ;
        }
        GuiTransmitStatus = TX_IDLE; 
        GuiClearCommand(GuiCurrentCommandProc);
    }
 
}

/*function that converts the register values received form the GUI application in framed ASCII format to decimal values*/
void GuiConvertWriteCommands(void)
{
    uint8_t TempCharacters[10];
    uint8_t DecodingIndex = 1;
    uint8_t DecodingSubindex = 0;
    uint8_t NumberLength = 0;
    static uint32_t WRegisterValue;
      
    while(GuiCommandBuffer[GuiCurrentCommandProc].CommandData[DecodingIndex-1] != '\r' && DecodingSubindex<15)
    {
        if(GuiCommandBuffer[GuiCurrentCommandProc].CommandData[DecodingIndex]!=',' && 
            GuiCommandBuffer[GuiCurrentCommandProc].CommandData[DecodingIndex]!='\r')
        {
            
            TempCharacters[NumberLength] = GuiCommandBuffer[GuiCurrentCommandProc].CommandData[DecodingIndex];
            NumberLength++;
        }
        else
        {
            GuiAsciiToDec(TempCharacters,&WRegisterValue,NumberLength);
            DecodedWriteCommand[DecodingSubindex] = WRegisterValue;
            DecodingSubindex++;
            NumberLength = 0;
        }
        DecodingIndex++;
    }
    
}


/*function that sets the digital potentiometer value*/
void GuiSetDigiPot(uint32_t value)
{
    mcp41010_hw_write_data(value);

}

/*function that selects the reference source*/
void GuiSetReferenceMux(uint32_t value)
{
    if(value == 1)
    {
        VREF_SELECT_Set();    
    }
    else
    {
        VREF_SELECT_Clear();
    }
}

/*function that sets the PWM used as a clock source to the MCP3564*/
void GuiSetSamplingSpeed(uint32_t value)
{
    TMR2_PeriodSet((value*4)-1);
    OCMP4_CompareSecondaryValueSet((value*2)-1);
}

/*function that writes the register values received form the GUI application to the MCP3564 registers*/
void GuiWriteRegisters(void)
{
    GuiConvertWriteCommands();
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG0_ADDRESS,
                            DecodedWriteCommand[0]);
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG1_ADDRESS,
                            DecodedWriteCommand[1]);
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG2_ADDRESS,
                            DecodedWriteCommand[2]);
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG3_ADDRESS,
                            DecodedWriteCommand[3]);
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_IRQ_ADDRESS,
                            DecodedWriteCommand[4]);
    MCP3564_DRV_WriteReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_MUX_ADDRESS,
                            DecodedWriteCommand[5]);
    MCP3564_DRV_WriteReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_SCAN_ADDRESS,
                            DecodedWriteCommand[6]);    
    MCP3564_DRV_WriteReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_TIMER_ADDRESS,
                            DecodedWriteCommand[7]);
    MCP3564_DRV_WriteReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_OFFSETCAL_ADDRESS,
                            DecodedWriteCommand[8]);
    MCP3564_DRV_WriteReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_GAINCAL_ADDRESS,
                            DecodedWriteCommand[9]);
    
    GuiSetSamplingSpeed(DecodedWriteCommand[10]);
    ConvertorSpeed = DecodedWriteCommand[10];
    GuiSetReferenceMux(DecodedWriteCommand[13]);
    ReferenceMux = DecodedWriteCommand[13];
    GuiSetDigiPot(DecodedWriteCommand[14]);
    DigiPotValue = DecodedWriteCommand[14];
}

/*function that converts a decimal value to a variable length ascii string of digits*/
static inline void Gui_DecimalToAsciiDinamic(uint32_t value, uint8_t* destString, uint8_t * length)
{
    uint8_t BCDValue[10] = {0};
    uint8_t FirstDigitFound=0;
    uint8_t i = 9;
    uint8_t j = 0;
    
    while(value>999999999)
    {
        value = value-1000000000;
        BCDValue[9]++;
    }
    
    while(value>99999999)
    {
        value = value-100000000;
        BCDValue[8]++;
    }
    while(value>9999999)
    {
        value = value-10000000;
        BCDValue[7]++;
    }    
    while(value>999999)
    {
        value = value-1000000;
        BCDValue[6]++;
    }   
    while(value>99999)
    {
        value = value-100000;
        BCDValue[5]++;
    }
    while(value>9999)
    {
        value = value-10000;
        BCDValue[4]++;
    }
    while(value>999)
    {
        value = value-1000;
        BCDValue[3]++;
    }
    while(value>99)
    {
        value = value-100;
        BCDValue[2]++;
    }
    while(value>9)
    {
        value = value-10;
        BCDValue[1]++;
    }
    
    BCDValue[0] = value;

    
    while(FirstDigitFound == 0)
    {
        if(BCDValue[i]==0)
        {
            i--;
        }
        else
        {
            *length = i+1;
            FirstDigitFound = 1;
        }
        if(i==0)
        {
            *length = i+1;
            FirstDigitFound = 1;            
        }
    }
    
    for(j = 0; j<*length; j++)
    {
        destString[j] = Gui_CharToAscii(BCDValue[(*length-1)-j]);
    }
}

/*function that reads the MCP3564 registers*/
void GuiReadResponseData(void)
{
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG0_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[0]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG1_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[1]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG2_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[2]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_CONFIG3_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[3]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_IRQ_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[4]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_MUX_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[5]);
    MCP3564_DRV_ReadReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_SCAN_ADDRESS,
                            &DecodedReadResponse[6]);
    MCP3564_DRV_ReadReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_TIMER_ADDRESS,
                            &DecodedReadResponse[7]);
    MCP3564_DRV_ReadReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_OFFSETCAL_ADDRESS,
                            &DecodedReadResponse[8]);
    MCP3564_DRV_ReadReg24(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_GAINCAL_ADDRESS,
                            &DecodedReadResponse[9]);
    MCP3564_DRV_ReadReg8(0,MCP3564_DRV_DEVICE_ADDRESS_1,
                            MCP3564_LOCK_ADDRESS,
                            (uint8_t *)&DecodedReadResponse[12]);    
    
    DecodedReadResponse[10]=ConvertorSpeed;
    DecodedReadResponse[11]=0;
    DecodedReadResponse[13] = ReferenceMux;
    DecodedReadResponse[14] = DigiPotValue;
}

/*function that implements the read registers command*/
void GuiReadRegisters(void)
{
    uint8_t i = 0;
    uint8_t additionalLenght = 0;
    
    GuiReadResponseData();
    EncodedReadResponse[0]= 'R';
    EncodedResonseLenght++;
    for(i = 0; i<15; i++)
    {
        Gui_DecimalToAsciiDinamic(DecodedReadResponse[i],&EncodedReadResponse[EncodedResonseLenght],&additionalLenght);
        EncodedResonseLenght = EncodedResonseLenght + additionalLenght;
        if(i<14)
        {
            EncodedReadResponse[EncodedResonseLenght] = ',';
            EncodedResonseLenght++;
        }
    }
    EncodedReadResponse[EncodedResonseLenght] = '\r';
    EncodedResonseLenght++;
    
}

/*function that starts the write registers command*/
void ProcessCommand_W(void)
{
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    ConverterStatus = ADC_WRITE_REG;
    GuiWriteRegisters();
    if(GuiTransmitStatus == TX_IDLE)
    {
        GuiShortTXBuffer[0]='W';
        GuiShortTXBuffer[1]='0';
        GuiShortTXBuffer[2]='\r';
        GuiTransmitStatus = TX_SENDING_SHORTDATA;
        UART2_Write(&GuiShortTXBuffer[0],3);
        while(GuiTransmitStatus !=TX_NOTIFIED)
        {
        ;
        }
        GuiTransmitStatus = TX_IDLE; 
        GuiClearCommand(GuiCurrentCommandProc);
    }
    ConverterStatus = ADC_IDLE;
}

/*function that starts the read registers command*/
void ProcessCommand_R(void)
{
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    ConverterStatus = ADC_READ_REG;
    GuiReadRegisters();
    if(GuiTransmitStatus == TX_IDLE)
    {
        GuiTransmitStatus = TX_SENDING_SHORTDATA;
        UART2_Write(&EncodedReadResponse,EncodedResonseLenght);
        EncodedResonseLenght = 0;
        while(GuiTransmitStatus !=TX_NOTIFIED)
        {
        ;
        }
        GuiTransmitStatus = TX_IDLE; 
        GuiClearCommand(GuiCurrentCommandProc);
        
    }
    ConverterStatus = ADC_IDLE;
}

/*function that performs the t command*/
void ProcessCommand_t(void)
{
    uint8_t i;
    uint8_t TCommandlength = 0;
    
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    if(GuiTransmitStatus == TX_IDLE)
    {
        if(GuiCommandBuffer[GuiCurrentCommandProc].CommandData[1] != '0')
        {
            TCommandlength=3;
        }
        else if(GuiCommandBuffer[GuiCurrentCommandProc].CommandData[2] != '0')
        {
            TCommandlength = 2;
        }
        else
        {
            TCommandlength = 1;
        }
        GuiShortTXBuffer[0]='t';
        for(i=1;i<=TCommandlength;i++)
        {
            GuiShortTXBuffer[TCommandlength-i+1]=GuiCommandBuffer[GuiCurrentCommandProc].CommandData[4-i];
        }
        GuiShortTXBuffer[TCommandlength+1]='\r';
        GuiTransmitStatus = TX_SENDING_SHORTDATA;
        UART2_Write(&GuiShortTXBuffer[0],TCommandlength+2);
        while(GuiTransmitStatus !=TX_NOTIFIED)
        {
        ;
        }
        GuiTransmitStatus = TX_IDLE; 
        GuiClearCommand(GuiCurrentCommandProc);
    } 
}

/*function that performs the start acquisition command*/
void ProcessCommand_s(void)
{
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    
    if(GuiTransmitStatus == TX_IDLE)
    {
        GuiShortTXBuffer[0]='s';
        GuiTransmitStatus = TX_SENDING_SHORTDATA;
        UART2_Write(&GuiShortTXBuffer[0],1);
        while(GuiTransmitStatus !=TX_NOTIFIED)
        {
            
        }
        GuiTransmitStatus = TX_IDLE; 
    } 
    while(UART2_WriteIsBusy())
    {
        ;/*wait for the UART buffered data to be transmitted
         before sending the echo of the command*/
    }
    ConverterStatus = ADC_READ_DATA;
    GuiChannelNumber = 0;
    CH0SampleCounter = 0;
    CH1SampleCounter = 0;
    EVIC_ExternalInterruptEnable( EXTERNAL_INT_1 );
    Gui_ResetAqTime();
    TMR4_Start();
}

/*function that performs the stop acquisition command*/
void ProcessCommand_p(void)
{
    EVIC_ExternalInterruptDisable( EXTERNAL_INT_1 );
    TMR4_Stop();
    GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus = COMMAND_EXECUTING;
    ConverterStatus = ADC_IDLE;
    GuiTransmitStatus = TX_IDLE;
    UART2_AbortWrite();
    while (UART2_WriteIsBusy())//wait for uart hardware fifo to empty
    {
    
    }
    
    GuiShortTXBuffer[0]='p';
    GuiShortTXBuffer[1]='0';
    GuiShortTXBuffer[2]='\r';
    GuiTransmitStatus = TX_SENDING_SHORTDATA;
    UART2_Write(&GuiShortTXBuffer[0],3);
    GuiTransmitStatus = TX_IDLE; 
    GuiClearCommand(GuiCurrentCommandProc);
}

/*function that looks in the command buffers and starts processing the commands*/
void ProcessCommand(void)
{
    if(GuiCommandBuffer[GuiCurrentCommandProc].CommandStatus == COMMAND_PENDING)
    {
        switch(GuiCommandBuffer[GuiCurrentCommandProc].CommandData[0])
        {
            case 'i':
            {
                ProcessCommand_i();
            }break;
            case 'v':
            {
                ProcessCommand_v();
            }break;
            case 'W':
            {
                ProcessCommand_W();
            }break;
            case 'R':
            {
                ProcessCommand_R();
            }break;
            case 't':
            {
                ProcessCommand_t();
            }break;
            case 's':
            {
                ProcessCommand_s();
            }break;
            case 'p':
            {
                ProcessCommand_p();
            }break;
            default:break;  
        }
    }
}

/*periodic function that executes the adc acquisition state machine*/
void Gui_AdcMain(void)
{
    switch(ConverterStatus)
    {
        case ADC_IDLE:
        {


        }break;
        case ADC_WRITE_REG:
        {


        }break;
        case ADC_READ_REG:
        {


        }break;
        case ADC_READ_DATA:
        {
            if(CH0AquisitionComplete&&CH1AquisitionComplete)
            {     
                EVIC_ExternalInterruptDisable( EXTERNAL_INT_1 );
                TMR4_Stop();
                CH0AquisitionComplete = 0;
                CH1AquisitionComplete = 0;
                Gui_PrepareAdcData();
                ConverterStatus = ADC_SEND_DATA;
            }

        }break;
        case ADC_SEND_DATA:
        {
            if(GuiTransmitStatus == TX_IDLE)
            {
                GuiTransmitStatus = TX_SENDING_ADCDATA;
                GuiSendAdcData();
            }
            if(GuiTransmitStatus == TX_FINISHED)
            {
                if(GuiCheckForPCommand())
                {
                    GuiTransmitStatus = TX_IDLE;
                    ConverterStatus = ADC_IDLE;
                    //GuiClearCommand(GuiCurrentCommandProc);
                }
                else
                {
                    GuiTransmitStatus = TX_IDLE;
                    ConverterStatus = ADC_READ_DATA;
                    CH0SampleCounter = 0;
                    CH1SampleCounter = 0;
                    EVIC_ExternalInterruptEnable( EXTERNAL_INT_1 );
                    Gui_ResetAqTime();
                    TMR4_Start();
                    
                }
            }

        }break;
    }
}

/*periodic function that implements the gui state machine*/
void Gui_Main(void)
{
    switch(GuiState)
    {
        case GUI_INIT :
        {
            GuiInit();
            GuiState = GUI_WAIT_FOR_CMD;
        }break;
        case GUI_WAIT_FOR_CMD :
        {
            GuiCheckCommand();
        }break;
        case GUI_PROCESSING_CMD :
        {
            ProcessCommand();
            GuiState = GUI_WAIT_FOR_CMD;
        }break;
        default:break;
    }
    Gui_AdcMain();
}