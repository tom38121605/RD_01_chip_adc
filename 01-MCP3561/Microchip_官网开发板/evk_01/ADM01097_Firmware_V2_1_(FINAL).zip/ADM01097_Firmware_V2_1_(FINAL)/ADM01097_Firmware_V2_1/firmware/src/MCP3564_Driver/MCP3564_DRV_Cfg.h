/*******************************************************************************
  Header file for MCP3564 driver configuration.

  Company:
    Microchip Technology Inc.

  File Name:
    MCP3563_DRV_Cfg.h

  Summary:
    Configuration header file for MCP3564 driver.

  Description:
    This file Provides access to configuration structures defined in MCP3563_DRV_Cfg.c

  Remarks:
    None.

*******************************************************************************/

/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef MCP3564_DRV_CFG_H
#define MCP3564_DRV_CFG_H

#include <stdint.h>
#include "definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    extern "C" {

#endif
// DOM-IGNORE-END
 
              
/*this macro defines the API used to set/clear a gpio pin (is used to control the chip select pin)*/        
#define MCP3564_SetGPIO(pin,level)                           GPIO_PinWrite(pin, level)     

/*this macro defines the API used to communicate over SPI*/   
#define MCP3564_SpiWriteRead(Wdata,Wlength,Rdata,Rlength)    SPI2_WriteRead(Wdata, Wlength, Rdata, Rlength) 

/*this macro defines the value of the level parameter of MCP3564_SetGPIO to activate the CS pin*/   
#define MCP3564_CS_ACTIVE_VALUE 0  

/*this macro defines the value of the level parameter of MCP3564_SetGPIO to deactivate the CS pin*/
#define MCP3564_CS_INACTIVE_VALUE 1

/*this macro defines the number of MCP3564 devices the driver can control*/
#define MCP3564_NUMBER_OF_DEVICES 1
 
        
        
 
typedef enum
{
    MCP3564_DRV_DEVICE_ADDRESS_0 = 0,
    MCP3564_DRV_DEVICE_ADDRESS_1 = 1,
    MCP3564_DRV_DEVICE_ADDRESS_2 = 2,
    MCP3564_DRV_DEVICE_ADDRESS_3 = 3 
}MCP3564_DRV_DeviceAddressType;       
extern const uint32_t MCP3563_DeviceCSPinList [MCP3564_NUMBER_OF_DEVICES];        
extern const MCP3564_DRV_DeviceAddressType MCP3563_DeviceAddressList [MCP3564_NUMBER_OF_DEVICES];        




// *****************************************************************************
// *****************************************************************************
// Section: Data Types
// *****************************************************************************
// *****************************************************************************

typedef union
{
    struct
    {
       uint32_t ADCDATA : 24;
       uint8_t UNIMPLEMENTED : 8;
    }B;
    uint32_t R;
}MCP3564_ADCDATAType;        
        
        
typedef union
{
    struct
    {
       uint8_t  ADC_MODE : 2;
       uint8_t  CS_SEL: 2;
       uint8_t  CLK_SEL : 2;
       uint8_t  CONFIG0 : 2;
    }B;
    uint8_t R;
}MCP3564_CONFIG0Type;
        
typedef union
{
    struct
    {
       uint8_t  Reserved : 2;
       uint8_t  OSR : 4;
       uint8_t  PRE : 2;
    }B;
    uint8_t R;
}MCP3564_CONFIG1Type;

typedef union
{
    struct
    {
       uint8_t  Reserved : 2;
       uint8_t  AZ_MUX : 1;
       uint8_t  GAIN : 3;
       uint8_t  BOOST : 2;
    }B;
    uint8_t R;
}MCP3564_CONFIG2Type;

typedef union
{
    struct
    {
       uint8_t  EN_GAINCAL : 1;
       uint8_t  EN_OFFCAL : 1;
       uint8_t  EN_CRCCOM : 1;
       uint8_t  CRC_FORMAT : 1;
       uint8_t  DATA_FORMAT : 2;
       uint8_t  CONV_MODE : 2;
    }B;
    uint8_t R;
}MCP3564_CONFIG3Type;

typedef union
{
    struct
    {
       uint8_t  EN_STP : 1;
       uint8_t  EN_FASTCMD : 1;
       uint8_t  IRQ_MODE : 2;
       uint8_t  POR_STATUS : 1;
       uint8_t  CRCCFG_STATUS : 1;
       uint8_t  DR_STATUS : 1;
       uint8_t  UNIMPLEMENTED : 1;
    }B;
    uint8_t R;
}MCP3564_IRQType;



typedef union
{
    struct
    {
       uint8_t  MUX_VIN_MINUS : 4;
       uint8_t  MUX_VIN_PLUS : 4;
    }B;
    uint8_t R;
}MCP3564_MUXType;


typedef union
{
    struct
    {
       uint16_t SCAN_SE_CH : 8;
       uint8_t  SCAN_DIFF_CH : 4;
       uint8_t  TEMP : 1;
       uint8_t  AVDD : 1;
       uint8_t  VCM : 1;
       uint8_t  OFFSET : 1;
       uint8_t  UNIMPLEMENTED2 : 4;
       uint8_t  RESERVED : 1;
       uint8_t  DLY : 3;
       uint8_t  UNIMPLEMENTED : 8;
    }B;
    uint32_t R;
}MCP3564_SCANType;

typedef union
{
    struct
    {
       uint32_t TIMER : 24;
       uint8_t UNIMPLEMENTED : 8;
    }B;
    uint32_t R;
}MCP3564_TIMERType;

typedef union
{
    struct
    {
       uint32_t OFFSETCAL : 24;
       uint8_t UNIMPLEMENTED : 8;
    }B;
    uint32_t R;
}MCP3564_OFFSETCALType;

typedef union
{
    struct
    {
       uint32_t GAINCAL : 24;
       uint8_t UNIMPLEMENTED : 8;
    }B;
    uint32_t R;
}MCP3564_GAINCALType;

typedef union
{
    struct
    {
       uint8_t  LOCK : 8;
    }B;
    uint8_t R;
}MCP3564_LOCKType;

typedef union
{
    struct
    {
       uint16_t  CRCCFG : 16;
    }B;
    uint16_t R;
}MCP3564_CRCCFGType;

typedef struct
{
    MCP3564_CONFIG0Type CONFIG0;
    MCP3564_CONFIG1Type CONFIG1;
    MCP3564_CONFIG2Type CONFIG2;
    MCP3564_CONFIG3Type CONFIG3;
    MCP3564_IRQType IRQ;
    MCP3564_MUXType MUX;
    MCP3564_SCANType SCAN;
    MCP3564_TIMERType TIMER;
}MCP3564_DRVConfigType;



// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

    }
#endif
// DOM-IGNORE-END

#endif /* MCP3564_DRV_CFG_H */
