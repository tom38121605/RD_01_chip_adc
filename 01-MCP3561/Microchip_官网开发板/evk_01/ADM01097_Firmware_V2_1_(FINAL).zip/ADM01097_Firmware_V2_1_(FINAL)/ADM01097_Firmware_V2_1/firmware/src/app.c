/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app.h"
#include "definitions.h"

#include "MCP3564_Driver/MCP3564_DRV.h"

#include "Gui.h"
#include "lcd_c0216ciz/lcd_c0216ciz.h"
#include "mcp41010/mcp41010.h"
#include "lcd_c0216ciz/bsp_i2c.h"
// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.

    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;

uint8_t ReceivedCharacter = 0;
// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/
void AppInit(void);
void AppTask3Ms(void);
// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;  
    
}

void Uart2_TXCallback( uintptr_t context )
{
    Gui_UartTxHandler();
}

void Uart2_RXCallback( uintptr_t context )
{
    Gui_UartRxHandler();
    UART2_Read( &ReceivedCharacter, 1 );
}
void Timer3Callback(uint32_t status, uintptr_t context)
{
    (void)status;
    (void)context;
    
    appData.App_Timer3Elapsed = 1;
}


void ExtInt1Callback(EXTERNAL_INT_PIN pin, uintptr_t context)
{

    Gui_INT1Handler();
}


void APP_Tasks ( void )
{

    /* Check the application's current state. */
    switch ( appData.state )
    {   
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            bool appInitialized = true;
            
            AppInit();
            if (appInitialized)
            {

                appData.state = APP_STATE_SERVICE_TASKS;
            }
            break;
        }

        case APP_STATE_SERVICE_TASKS:
        {
            if(appData.App_Timer3Elapsed == 1)
            {
                AppTask3Ms();
                appData.App_Timer3Elapsed = 0;
            }
            if(GuiMainRerady == 1)
            {
                Gui_Main();

                mcp41010_main_loop();

                lcd_c0216ciz_main_loop();

            }
            
            break;
        }



        /* The default state should never be executed. */
        default:
        {

            break;
        }
    }
}



void AppInit(void)
{

    UART2_WriteCallbackRegister( Uart2_TXCallback, (uintptr_t) NULL );
    UART2_ReadCallbackRegister( Uart2_RXCallback, (uintptr_t) NULL );
    TMR3_CallbackRegister( Timer3Callback, (uintptr_t) NULL );
    TMR3_Start();
    TMR2_Start();
    OCMP4_Enable();
    bsp_init_i2c2(1);
    EVIC_ExternalInterruptCallbackRegister(EXTERNAL_INT_1,ExtInt1Callback,(uintptr_t) NULL);
    lcd_c0216ciz_init();
    lcd_c0216ciz_turn_on();


}

volatile uint32_t taskCounter = 0;
volatile uint8_t executeOnce = 0;
void AppTask3Ms(void)
{
    taskCounter++;
    /*taskCounter is used to create a 30 ms delay
     between startup and initialization of devices*/
    if(taskCounter == 10 && executeOnce == 0)
    {
        lcd_c0216ciz_print_line(0, "MCP3564 4Ch Demo");
        UART2_Read( &ReceivedCharacter, 1 );
        executeOnce++;
        
        MCP3564_DRV_Init(0,&MCP3563Confg);
        MCP3564_DRV_SetOFFSETCAL(0,0);
        MCP3564_DRV_SetGAINCAL(0,0);
    }
    if(taskCounter == 15)
    {
        GuiMainRerady = 1;
        
    }
    
    lcd_c0216ciz_on_tick_isr();
    
    if(!SW3_Get())
    {
        LED3_Set();
    }
    else
    {
        LED3_Clear();
    }
    
    if(!SW4_Get())
    {
        LED4_Set();
    }
    else
    {
        LED4_Clear();
    }
    
    
}
/*******************************************************************************
 End of File
 */
