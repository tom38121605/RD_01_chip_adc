/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "interrupts.h"
#include "bsp.h"
#include "bsp_i2c.h"
#include "app.h"
#include "usb_device.h"
#include "uart_buffer/uart_buffer_internal.h"
#include "lcd_c0216ciz/lcd_c0216ciz_internal.h"
#include "mcp3564/mcp3564_internal.h"
#include "mcp3564/mcp3564.h"
#include "mcp3564/mcp3564_register_defs.h"


void __attribute__ ((interrupt, vector(_TIMER_1_VECTOR))) _T1Interrupt(void)            
{
  restart_adc();
  IFS0bits.T1IF = 0;
}

void __attribute__ ((interrupt, vector(_TIMER_3_VECTOR))) _T3Interrupt(void)            
{
  app_tick++;
  lcd_c0216ciz_on_tick_isr();
  IFS0bits.T3IF = 0;
}

void __attribute__ ((interrupt, vector(_EXTERNAL_1_VECTOR))) _INT1Interrupt(void)       
{
  mcp3564_on_data_ready();
  //read_data_();
  IFS0bits.INT1IF = 0;
}

void __attribute__ ((interrupt,  vector(_I2C_2_VECTOR))) _I2C2MInterrupt(void)
{
  bsp_i2c2_isr();
  IFS1bits.I2C2MIF = 0;
}

void __attribute__ ((interrupt, vector(_UART_2_VECTOR))) _UART2Interrupt(void)
{
  uint8_t c;

  // Is this an RX interrupt?
  if(IFS1bits.U2RXIF)
  {
    uint8_t c;
    while(U2STAbits.URXDA)
    {
      c = U2RXREG;
      uart_buffer_hw_on_rx(c);
    }
    // Clear the RX interrupt Flag
    IFS1bits.U2RXIF = 0;
  }

  if (IFS1bits.U2TXIF)
  {
    if(uart_buffer_hw_on_tx(&c))
    {
      U2TXREG = c;
    }
    else
    {
      uart_buffer_hw_tx_set_ready();
      IEC1bits.U2TXIE = 0;
    }
    
    IFS1bits.U2TXIF = 0;
  }
}

void _general_exception_handler(unsigned cause, unsigned status)
{
  volatile unsigned int excep_code;
  volatile unsigned int excep_addr;

  excep_code = (cause & 0x0000007C) >> 2;
  excep_addr = __builtin_mfc0(_CP0_EPC, _CP0_EPC_SELECT);
  if ((cause & 0x80000000) != 0)
  {
    excep_addr += 4;
  }

  while(1);
}

void clear_T3_flag()
{
IFS0bits.T3IF = 0;
}