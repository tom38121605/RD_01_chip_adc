/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "gui.h"
#include "usb_vcp/usb_vcp.h"
#include "uart_buffer/uart_buffer.h"
#include "mcp3564/mcp3564.h"
#include "app.h"
#include <string.h>
#include <stdio.h>  //snprintf
#include "bsp.h"
#include "io/io.h"

#define GUI_RX_BUFFER_SIZE    512
#define GUI_TX_BUFFER_SIZE    256

static enum
{
  GUI_USE_UART = 0,
  GUI_USE_USB = 1,
} gui_communication_way;

static uint8_t gui_rx_buffer[GUI_RX_BUFFER_SIZE];
static uint8_t temp[10];
static uint32_t time;
static uint16_t gui_rx_buffer_in;
static uint16_t gui_rx_buffer_out;

static uint8_t gui_rx_command[GUI_RX_BUFFER_SIZE];
static uint16_t gui_rx_command_count;

static uint8_t gui_tx_buffer[GUI_RX_BUFFER_SIZE];

static uint8_t gui_adc_started;

static uint32_t gui_adc_register_shadow[15];
static uint32_t gui_adc_timer_shadow;
static uint8_t gui_adc_restart;
static uint8_t gui_adc_start;
static uint8_t gui_adc_delay;
static uint8_t gui_adc_stop;
static uint16_t gui_adc_sample_no;
static uint16_t gui_adc_sample_tx;
static uint8_t gui_adc_channel_no;
static int32_t gui_adc_buffer[2];

static void gui_process_rx();

static void gui_send_data(const char *s, const uint16_t l);
static uint8_t gui_send_empty();
static void usb_vcp_rx_callback(const char c);
static void uart_buffer_rx_callback(const char c);

static void my_utoa(const uint32_t i, char *a, uint16_t *len);
static void hex_to_dec(const uint32_t i, char *a, uint16_t *len, uint16_t c);

static void mcp3564_on_write_finish();
static void mcp3564_on_read_finish(const uint32_t *registers);
static void mcp3564_on_data(const int32_t new_value);

int32_t buff_ch0[buffer_lenght];
int32_t buff_ch1[buffer_lenght];
uint32_t counter, counter1;
uint32_t pause;
uint8_t tx_buf[10];
int start =0;

uint8_t gui_send_buff;

void gui_init()
{
  gui_communication_way = GUI_USE_UART;

  gui_rx_buffer_in = 0;
  gui_rx_buffer_out = 0;
  gui_rx_command_count = 0;

  gui_adc_started = 0;
  gui_adc_timer_shadow = 0;
  gui_adc_restart = 0;
  gui_adc_start = 0;
  gui_adc_stop = 0;

  gui_send_buff = 0;
  gui_adc_sample_no = 0;
  gui_adc_sample_tx = 0;
  gui_adc_channel_no = 0;

  usb_vcp_turn_on();
  usb_vcp_enable_rx_callback(usb_vcp_rx_callback);
  uart_buffer_enable_rx_callback(uart_buffer_rx_callback);

  mcp3564_enable_callback(mcp3564_on_data);
  
  snprintf(temp, 10,"%2.4f",(double)25.00);  
}

void gui_main_loop()
{
  gui_send_real_data(); 
  while(gui_rx_buffer_in != gui_rx_buffer_out)
  {
    gui_rx_command[gui_rx_command_count] = gui_rx_buffer[gui_rx_buffer_out];
    
    gui_rx_command_count++;
    gui_rx_buffer_out++;
    if(gui_rx_buffer_out >= GUI_RX_BUFFER_SIZE)
    {
      gui_rx_buffer_out = 0;
    }

    if(gui_rx_command_count > 1)
    {
      if(gui_rx_command[gui_rx_command_count - 1] == '\r')
      {
        gui_rx_command_count--;
        gui_process_rx();
      }
    }
  } 

  if(gui_adc_stop)
  {
    gui_adc_stop = 0;
    gui_adc_sample_no = 0;
    gui_adc_sample_tx = 0;
    gui_adc_started = 0;
    stop_T1_int();
    gui_send_data("p0\r", 3);
  }
}

static void gui_process_rx()
{
  uint16_t i;
  uint16_t j;
  uint16_t k;

  switch(gui_rx_command[0])
  { 
    default:
      if(gui_rx_command[gui_rx_command_count - 1] != 'i')
          break;
    
    case 'i': //board identify
      gui_send_data("iADM01097\r", 10);
      break;

    case 'v': //board version identify
      gui_send_data("v0.0.1\r", 7);
      break;

    case 'W': //write register
      i = 1;
      j = 0;
      while(i < gui_rx_command_count)
      {
        gui_adc_register_shadow[j] = 0;
        while((i < gui_rx_command_count) && (gui_rx_command[i] >= '0') && (gui_rx_command[i] <= '9'))
        {
          gui_adc_register_shadow[j] *= 10;                                     
          gui_adc_register_shadow[j] += gui_rx_command[i] - '0';
          i++;
        }
        j++;

        if((j < 15) && (gui_rx_command[i] != ','))
        {
          //error                                                               
          break;
        }
        else
        {
          i++;
        }
      }
      
      if(j < 15)
      {
        //report error
        gui_send_data("W1\r", 3);
      }
      else
      {
        //report data send ok
        mcp3564_write_all_registers(gui_adc_register_shadow, mcp3564_on_write_finish);
        gui_adc_channel_no = 0;                                                  
      }
      break;

    case 'R': //read register
      mcp3564_read_all_registers(mcp3564_on_read_finish);
      break;

    case 't': //timer write
      i = 1;
      j = 0;
      while((i < gui_rx_command_count) && (gui_rx_command[i] >= '0') && (gui_rx_command[i] <= '9'))
      {
        j *= 10;
        j += gui_rx_command[i] - '0';
        i++;
      }

      if(j != 0)
      {
        gui_adc_timer_shadow = j;
      }

      i = 1;
      gui_tx_buffer[0] = 't';
      my_utoa(gui_adc_timer_shadow, (char*)gui_tx_buffer + i, &k);
      i += k;
      gui_tx_buffer[i] = '\r';
      i++;
      gui_send_data((char*)gui_tx_buffer, i);
      break;

    case 's': //data transmit
        gui_adc_start = 1;   
        start_int1();
      break;
    
    case 'p': //data stop transmit
        gui_adc_stop = 1;
        stop_int1();
        led3_off();
        break;
  }
  gui_rx_command_count = 0;
}

static void gui_send_data(const char *s, const uint16_t l)
{
  switch(gui_communication_way)
  {
    case GUI_USE_UART:
      uart_buffer_schedule_send(s, l);
      break;
    
    case GUI_USE_USB:
      usb_vcp_schedule_send(s, l);
      break;
  }
}

static uint8_t gui_send_empty()
{
  switch(gui_communication_way)
  {
    case GUI_USE_UART:
      return uart_buffer_schedule_send_empty();
      break;
    
    case GUI_USE_USB:
      return usb_vcp_schedule_send_empty();
      break;
  }

  return 0;
}

static void usb_vcp_rx_callback(const char c)
{
  gui_communication_way = GUI_USE_USB;

  gui_rx_buffer[gui_rx_buffer_in] = c;
  gui_rx_buffer_in++;
  if(gui_rx_buffer_in >= GUI_RX_BUFFER_SIZE)
  {
    gui_rx_buffer_in = 0;
  }
}

static void uart_buffer_rx_callback(const char c)
{
  gui_communication_way = GUI_USE_UART;

  gui_rx_buffer[gui_rx_buffer_in] = c;
  gui_rx_buffer_in++;
  if(gui_rx_buffer_in >= GUI_RX_BUFFER_SIZE)
  {
    gui_rx_buffer_in = 0;
  }
}

//not null-terminated
static void my_utoa(const uint32_t i, char *a, uint16_t *len)
{
  uint32_t iv = i;
  uint8_t c = 0;
  uint8_t j = 0;

  char x[11];

  if(i == 0)
  {
    a[0] = '0';
    *len = 1;
    return;
  }
  
  while(iv != 0)
  {
    x[c] = (iv % 10);
    iv /= 10;
    if(x[c] > 9)
    {
      x[c] += 'a' - 10;
    }
    else
    {
       x[c] += '0';
    }
    c++;
  }

  while(c != 0)
  {
    c--;
    a[j++] = x[c];
  }

  *len = j;
}

 static void hex_to_dec(const uint32_t count, char *a, uint16_t *len, uint16_t c)
{	
  char ones;
  char tens;
  char hundreds;
  char thousands;
  char thousand10s;
  char thousand100s;
  char mill;
  char mill10s;
  char mill100s;
  char bills;
    
  bills=0;
  mill100s=0;
  mill10s=0;			
  mill=0;
  thousand100s=0;
  thousand10s=0;
  thousands=0;
  hundreds=0;
  tens  = 0;						
  ones = 0;
    
  uint32_t iv = count;
  uint8_t j = 0;
 
  while ( iv >= 1000000000 )
  {
	iv -= 1000000000;			// subtract 100000
    bills++;					// increment 10thousands
  }

  while ( iv >= 100000000 )
  {
	iv -= 100000000;			// subtract 100000	
	mill100s++;					// increment 10thousands
  }

  while ( iv >= 10000000 )
  {
	iv -= 10000000;             // subtract 100000	
	mill10s++;					// increment 10thousands
  }

  while ( iv >= 1000000 )
  {
	iv -= 1000000;              // subtract 100000	
	mill++;                     // increment 10thousands
  }
	
  while ( iv >= 100000 )
  {
	iv -= 100000;               // subtract 100000
	thousand100s++;				// increment 10thousands
  }
	
  while ( iv >= 10000 )
  {
	iv -= 10000;                // subtract 10000		
	thousand10s++;				// increment 10thousands
  }

  while ( iv >= 1000 )
  {
	iv -= 1000;                 // subtract 1000
	thousands++;                // increment thousands
  }

  while ( iv >= 100 )
  {
	iv -= 100;                  // subtract 100	
	hundreds++;					// increment hundreds
  }

  while ( iv >= 10 )
  {
	iv -= 10;                   // subtract 10	
    tens++;                     // increment tens
  }

  ones = iv;					// remaining count equals ones

  a[c++]=bills+0x30;
  a[c++]=mill100s+0x30;
  a[c++]=mill10s+0x30;
  a[c++]=mill+0x30;
  a[c++]=thousand100s+0x30;
  a[c++]=thousand10s+0x30;
  a[c++]=thousands+0x30;
  a[c++]=hundreds+0x30;
  a[c++]=tens+0x30;
  a[c++]=ones+0x30;	
  *len = c;
}

static void mcp3564_on_write_finish()
{
  gui_send_data("W0\r", 3);
}

static void mcp3564_on_read_finish(const uint32_t *registers)
{
  uint16_t i;
  uint16_t j;
  uint16_t k;

  gui_tx_buffer[0] = 'R';
  i = 1;
  for(j = 0; j < 15; j++)
  {
    my_utoa(gui_adc_register_shadow[j], (char*)gui_tx_buffer + i, &k);
    i += k;
    gui_tx_buffer[i] = ',';
    i++;
  }

  i--;          //rewrite last ','
  gui_tx_buffer[i] = '\r';
  i++;
  gui_send_data((char*)gui_tx_buffer, i);
}

static void mcp3564_on_data(const int32_t new_value)
{  
  if(gui_adc_start)
  {
    if(gui_adc_channel_no == 0)
    {
      gui_adc_sample_no = 0;
      gui_send_data("s", 1);
      gui_adc_started = 1;
      gui_adc_start = 0;
      start_int1();
      start_T4();           // start T4 to measure acquisition time 
    }
  }
  
  if(gui_adc_restart)
  {
    uint32_t i; 
    
    while (i < buffer_lenght+1)
    {   
      buff_ch0[i] = 0;
      buff_ch1[i] = 0;
      i++;
    }
    gui_adc_started = 1;
    gui_adc_restart = 0;  
    start_T4();             // start T4 to measure each data- frame acquisition time 
  }

  if(gui_adc_started)
  {
    gui_adc_buffer[gui_adc_channel_no] = new_value;

    if(gui_adc_channel_no)
    {
      buff_ch0[gui_adc_sample_no] = gui_adc_buffer[0];
      buff_ch1[gui_adc_sample_no] = gui_adc_buffer[1];
        
      gui_adc_sample_no++;
      
      if(gui_adc_sample_no >= buffer_lenght+1)
      {
        led3_off(); 
        stop_int1();
        stop_T4();          // stop T4 to measure acquisition time 
        gui_send_buff = 1;
        gui_adc_started = 0;
        gui_adc_sample_no = 0;
        gui_adc_sample_tx = 0;
        gui_send_data("!", 1);
      }
    }
  }

  if(gui_adc_channel_no)
  {
    gui_adc_channel_no = 0;
  }
  else
  {
    gui_adc_channel_no = 1;
  }
}

void restart_adc()
{
  if(gui_send_empty())
  {
    gui_adc_restart = 1;
    start_int1();
    stop_T1_int();
    led3_on();
  }
}

void gui_send_real_data()
{
  char a[45];
  uint16_t len, j,c;
  uint8_t i, x;   
    
  if(gui_send_buff && gui_send_empty())
  {
    x = 0;
    while((x < 10) && gui_send_buff)
    {
      if (gui_adc_sample_tx == 0)
      {
        gui_adc_sample_tx++;            // cut off first sample
      }                   
      len=0;
      j=0;
      c=0;
      hex_to_dec(buff_ch0[gui_adc_sample_tx], a, &len,c);
      a[len++] = ',';
      c = len;
      hex_to_dec(buff_ch1[gui_adc_sample_tx], a, &len,c);

      gui_adc_sample_tx++;
      if(gui_adc_sample_tx >= buffer_lenght +1)
      {
        gui_send_buff = 0;
        gui_adc_sample_tx = 0;

        a[len++] = ':';
        c = len;
        hex_to_dec(get_aq_time(), a, &len, c);
         
        a[len++] = ',';
        i = 0;
        while (i<8)
        {
          a[len++] = temp[i];
          i++;
        }
        a[len++] = '\r';
        
        start_T1_int();         // T4 int is used for delay between data-frames
      }
      else
      {
        a[len++] = ';';
      }
      gui_send_data(a, len);
      x++;   
    }
  }
}

void counter_x()
{
    counter++;
}
void counter_y()
{
    counter1++;
}

void set_sampling_speed(uint32_t i)         // set PWM Frq that is external clk for the ADC
{
  uint32_t per;
  uint8_t x,y;
    
  if (i==1)
  {
    per = 1;
    x = 1;
    y = 1;
  }
  else
  {
    per =((i*2)-1);
    x = per/2;
    y = x;
  }
  set_new_osc_value(per,x,y);
}