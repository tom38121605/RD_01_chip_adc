/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "app.h"
#include "core/core.h"
#include "uart_buffer/uart_buffer.h"
#include "usb_vcp/usb_vcp.h"
#include "io/io.h"
#include "lcd_c0216ciz/lcd_c0216ciz.h"
#include "mcp3564/mcp3564.h"
#include "bsp.h"
#include "gui/gui.h"

#include <stdio.h>      //snprinf

volatile uint32_t app_tick;

void app_init()
{
  app_tick = 0;
  core_init_usb_power();
  while(app_tick == 0);  //wait 100ms for power

  uart_buffer_init();
  usb_vcp_init();
  io_init();
  lcd_c0216ciz_init();
  mcp3564_init();
  mcp41010_init();

  gui_init();

  lcd_c0216ciz_turn_on();
  mcp3564_turn_on();
}

void app_main_loop()
{    
  usb_vcp_main_loop();
  lcd_c0216ciz_main_loop();
  mcp3564_main_loop();
  mcp41010_main_loop();
  
  gui_main_loop();
  
  io_set_led(IO_LED_3, io_get_button_pressed(IO_BUTTON_3));
  io_set_led(IO_LED_4, io_get_button_pressed(IO_BUTTON_4));

  lcd_c0216ciz_print_line(0, "MCP3564 4Ch Demo"); 
}