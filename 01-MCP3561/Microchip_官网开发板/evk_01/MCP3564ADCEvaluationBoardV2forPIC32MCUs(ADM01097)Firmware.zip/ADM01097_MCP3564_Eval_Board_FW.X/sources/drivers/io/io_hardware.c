/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "io_internal.h"
#include "bsp.h"
#include <assert.h>

void led3_off()
{
  LED3 = LED_OFF;
}

void led4_off()
{
  LED4 = LED_OFF;
}

void led3_on()
{
  LED3 = LED_ON;
}

void led4_on()
{
  LED4 = LED_ON;
}

uint8_t button2_pressed()
{
  return (SW2 == SWITCH_PRESSED);
}

uint8_t button3_pressed()
{
  return (SW3 == SWITCH_PRESSED);
}

uint8_t button4_pressed()
{
  return (SW4 == SWITCH_PRESSED);
}