/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "io.h"
#include "io_internal.h"
#include <string.h>
#include <assert.h>

void io_init()
{
  led3_off();
  led4_off();
}

uint8_t io_get_button_pressed(const io_button_t button)
{
  switch(button)
  {
    case IO_BUTTON_2:
      return button2_pressed();
      break;

    case IO_BUTTON_3:
      return button3_pressed();
      break;

    case IO_BUTTON_4:
      return button4_pressed();
      break;
  }
  return 255;
}

void io_set_led(const io_led_t led, const uint8_t on)
{
  switch(led)
  {
    case IO_LED_3:
      if(on)
      {
        led3_on();
      }
      else
      {
        led3_off();
      }
      break;

    case IO_LED_4:
      if(on)
      {
        led4_on();
      }
      else
      {
        led4_off();
      }
      break;
  }
}