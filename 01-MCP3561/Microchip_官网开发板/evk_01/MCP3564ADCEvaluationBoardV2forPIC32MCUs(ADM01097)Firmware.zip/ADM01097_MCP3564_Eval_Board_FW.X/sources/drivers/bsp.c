/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "bsp.h"

#pragma config UPLLEN   = ON            // USB PLL Enabled
#pragma config FPLLMUL  = MUL_20        // PLL Multiplier
#pragma config UPLLIDIV = DIV_2         // USB PLL Input Divider
#pragma config FPLLIDIV = DIV_2         // PLL Input Divider
#pragma config FPLLODIV = DIV_1         // PLL Output Divider
#pragma config FPBDIV   = DIV_1         // Peripheral Clock divisor
#pragma config FWDTEN   = OFF           // Watchdog Timer
#pragma config WDTPS    = PS1           // Watchdog Timer Postscale
#pragma config FCKSM    = CSDCMD        // Clock Switching & Fail Safe Clock Monitor
#pragma config OSCIOFNC = OFF           // CLKO Enable
#pragma config POSCMOD  = HS            // Primary Oscillator
#pragma config IESO     = OFF           // Internal/External Switch-over
#pragma config FSOSCEN  = OFF           // Secondary Oscillator Enable (KLO was off)
#pragma config FNOSC    = PRIPLL        // Oscillator Selection
#pragma config CP       = OFF           // Code Protect
#pragma config BWP      = OFF           // Boot Flash Write Protect
#pragma config PWP      = OFF           // Program Flash Write Protect
#pragma config ICESEL   = ICS_PGx2      // ICE/ICD Comm Channel Select


void bsp_init_cpu(const uint8_t mode)
{
  OSCConfig(OSC_POSC_PLL, OSC_PLL_MULT_20, OSC_PLL_POST_2, OSC_FRC_POST_1);
  SYSTEMConfigPerformance(FOSC_PLL); 
  mOSCSetPBDIV(OSC_PB_DIV_1);           // Use 1:1 CPU Core:Peripheral clocks
      
  DDPCONbits.JTAGEN = 0;
  DDPCONbits.TROEN = 0;
  
  RCON = 0x00;                          // Reset control register
  
  asm volatile ("di");
  INTCONbits.MVEC = 1;
  asm volatile ("ei");
}

void bsp_init_ports(const uint8_t mode)
{
  SW2_DIR = PORT_DIR_INPUT;
  SW3_DIR = PORT_DIR_INPUT;
  SW4_DIR = PORT_DIR_INPUT;

  LED3_DIR = PORT_DIR_OUTPUT;
  LED4_DIR = PORT_DIR_OUTPUT;
  
  LED3 = LED_OFF;
  LED4 = LED_OFF;
  
  IC_SW_DIR = PORT_DIR_OUTPUT;

  UART_RX_DIR = PORT_DIR_INPUT;
  UART_TX_DIR = PORT_DIR_OUTPUT;

  SDA2_DIR = PORT_DIR_OUTPUT;                   // Set SDA associated pin as output
  SDA2 = 1;
  SCL2_DIR = PORT_DIR_OUTPUT;                   // Set SCL associated pin as output
  SCL2 = 1;

  ADC_CLOCK_DIR = PORT_DIR_OUTPUT;
  ADC_CLOCK = 0;

  ADC_DATA_READY_DIR = PORT_DIR_INPUT;

  DP_CS_DIR = PORT_DIR_OUTPUT; 
  ADC_CS_DIR = PORT_DIR_OUTPUT;  
  ADC_SCLK_DIR = PORT_DIR_INPUT;
  ADC_MOSI_DIR = PORT_DIR_OUTPUT;
  ADC_MISO_DIR = PORT_DIR_INPUT;

  ADC_CS = 1;
  DP_CS = 1;
}

void bsp_init_timers(const uint8_t mode)
{
  PWM4_PR2 = 19;                                // set by default PWM to 2MHZ  
  PWM4_OC4R =  9;                               // set by default PWM to 50% DC  
  PWM4_OC4RS = 9;
 
  INTCONbits.INT1EP = 0;                        //interrupt on negative edge
  
  IFS0bits.INT1IF = 0;
  IPC1bits.INT1IP = 7;
  IEC0bits.INT1IE = 0;
  
  // Configure Timer 2        
  T2CONbits.TSIDL = 0;                          //continues module operation in Idle mode
  T2CONbits.TCKPS = 0;                          //sets prescaler to 1:1
  PR2 = PWM4_PR2;                               //FOSC_PLL / 2 / 256 / TIMER3_FREQUENCY;        //sets the period register for timer 2 
  
  // Configure Timer 3 Interrupt
  T3CONbits.TSIDL = 0;                          //continues module operation in Idle mode
  T3CONbits.TCKPS = 3;                          //sets prescaler to 1:256
  PR3 = FOSC_PLL / 2 / 256 / TIMER3_FREQUENCY;  //sets the period register for timer 3 

  IFS0bits.T3IF = 0;
  IPC3bits.T3IP = 6; 
  IEC0bits.T3IE = 1;
  
  T3CONbits.TON = 1;                            //starts 16-bit timer3

  // Configure Timer 1 Interrupt
  T1CONbits.TSIDL = 0;                          //continues module operation in Idle mode
  T1CONbits.TCKPS = 3;                          //sets prescaler to 1:256
  PR1 = 39058;                                  //FOSC_PLL / 2 / 256 / TIMER1_FREQUENCY;        //sets the period register for timer 1   = 250 ms 
  
  IFS0bits.T1IF = 0;
  IPC1bits.T1IP = 5;
  IEC0bits.T1IE = 1;
  
  T1CONbits.TON = 0;                            // 16-bit timer1
  
  //CONFIG TIMER 4 32bit
  T4CON = 0x0;                                  // Stop 16-bit Timer4 and clear control register
  T5CON = 0x0;                                  // Stop 16-bit Timer5 and clear control register
  T4CONbits.TCKPS = 0x0;                        // Enable 32-bit mode, prescaler at 1:1,
  T4CONbits.T32=1;
  // internal clock source
  TMR4 = 0x0;                                   // Clear contents of the TMR4 and TMR5
  TMR5 = 0x0;
  PR4 = 0xFFFFFFFF;                             // Load PR4 and PR5 registers with 32-bit value
  T4CONbits.TON=0;
}

void reset_timer_2()
{
  T2CONbits.TSIDL = 0;                          //continues module operation in Idle mode
  T2CONbits.TCKPS = 0;                          //sets prescaler to 1:1
  PR2 = PWM4_PR2;                               //FOSC_PLL / 2 / 256 / TIMER3_FREQUENCY;        //sets the period register for timer 2 
}
  
void bsp_init_output_compare(const uint8_t mode)
{ 
  OC4CON = 0;
  OC4CONbits.OCTSEL = 0;                        // Clock source is Timer 2
  OC4CONbits.OCM = 6;                           // Edge Aligned PWM mode
  OC4CONbits.OCFLT  = 0;

  // Modulation setup
  OC4R = PWM4_OC4R;
  OC4RS = PWM4_OC4RS;
  OC4CONbits.ON = 1;
}

void bsp_init_spi2(const uint8_t mode)
{
  SPI2CONbits.FRMEN = 0;            //  FRAME_ENABLE_OFF
  SPI2CONbits.FRMSYPW = 0;          //  FRAME_SYNC_OUTPUT
  SPI2CONbits.DISSDO = 0;           //  ENABLE_SDO_PIN
  SPI2CONbits.MODE16 = 0;           //  SPI_MODE16_OFF
  SPI2CONbits.SMP = 1;              //  SPI_SMP_ON
  SPI2CONbits.CKE = 1;              //  SPI_CKE_ON
  SPI2CONbits.SSEN = 0;             //  SLAVE_ENABLE_OFF
  SPI2CONbits.CKP = 0;              //  CLK_POL_ACTIVE_HIGH
  SPI2CONbits.MSTEN = 1;            //  MASTER_ENABLE_ON
  SPI2CONbits.SIDL = 0;             //  SPI_IDLE_CON
  SPI2STATbits.SPIROV = 0;          //  SPI_RX_OVFLOW_CLR
  SPI2CONbits.FRMPOL = 0;           //  FRAME_POL_ACTIVE_LOW
  SPI2CONbits.SPIFE = 0;            //  FRAME_SYNC_EDGE_PRECEDE   
  SPI2CONbits.ON = 1;               //  SPI_ENABLE
}

void bsp_init_uart(const uint8_t mode)
{
  U2MODEbits.UEN = 0;               //rx+tx only
  U2MODEbits.WAKE = 0;              //no wake
  U2MODEbits.IREN = 0;              //no ir
  U2MODEbits.LPBACK = 0;            //no loopback
  U2MODEbits.ABAUD = 0;             //no auto baud
  U2MODEbits.BRGH = 1;              //high baud rate
  U2MODEbits.STSEL = 0;             //one stop bit
  U2MODEbits.PDSEL = 0;             //8 bit data, no parity

  U2STAbits.UTXISEL0 = 0;           //interrupt when uart tx buffer is empty
  U2STAbits.UTXINV = 0;             //normal tx
  U2STAbits.URXEN = 1;              //allow receive
  U2STAbits.UTXBRK = 0;             //no break
  U2STAbits.UTXEN = 1;              //enable tx
  U2STAbits.URXISEL = 0;            //interrupt when there is a char in fifo
  U2STAbits.ADDEN = 0;              //disable addresing
  U2STAbits.OERR = 0;               //clear if any error

  U2BRG = FCY_PLL/4/UART_BAUDRATE - 1;  //((CRYSTAL_FREQ * PLL_M) / ( PLL_N * 8 * UART_BAUDRATE));//

  U2MODEbits.UARTEN = 1;
  U2STAbits.URXEN = 1;              //allow receive
  U2STAbits.UTXEN = 1;              //enable tx AGAIN

  IFS1bits.U2RXIF = 0;
  IFS1bits.U2TXIF = 0;
  IPC8bits.U2IP = 4;                // priority
  IEC1bits.U2RXIE = 1;
}

void start_T1_int()
{
  TMR1 = 0;
  IFS0bits.T1IF = 0;
  T1CONbits.TON = 1;                //starts 16-bit timer1
}

void stop_T1_int()
{
  TMR1 = 0;    
  IFS0bits.T1IF = 0;
  T1CONbits.TON = 0;                //starts 16-bit timer1
}

void start_T4()
{
  TMR4 = 0x0;                       // Clear contents of the TMR4 and TMR5
  TMR5 = 0x0;
  PR4 = 0xFFFFFFFF;                 // Load PR4 and PR5 registers with 32-bit value
  T4CONbits.TON=1;
}

void stop_T4()
{
  T4CONbits.TON=0;
}

uint32_t get_aq_time ()
{
  uint32_t i, time;
    
  i = 65536*TMR5+TMR4;
   
  i = i / 10000;                    // value is for u seconds
  time = 125*i;                     // CLK for 32 bit Timer 1:1 PR is 80 Mhz
  return time;
}

void set_sw_value(uint32_t value)
{
  if (value == 0)
    IC_SW = SW_VREF;
  else if (value == 1)
    IC_SW = SW_DP;
}

void start_int1()
{
  IEC0bits.INT1IE = 1;
}

void stop_int1()
{
  IEC0bits.INT1IE = 0;
}

void set_new_osc_value(uint32_t i, uint8_t x, uint8_t y)
{
  disable_output_compare();

  PWM4_PR2  = i;            
  PWM4_OC4R     = x;    
  PWM4_OC4RS        =y; 

  reset_timer_2();
  bsp_init_output_compare(BSP_INIT_USB_POWER);         // enable OCC 4
}

void disable_output_compare()
{
  OC4CONbits.ON = 0;
}