/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "core.h"
#include "bsp.h"
#include "bsp_i2c.h"

static enum
{
  CORE_UNINITIALIZED_POWER = 0,
  CORE_USB_POWER,
} core_power_mode = CORE_UNINITIALIZED_POWER;

void core_init_usb_power()
{
  bsp_init_cpu(BSP_INIT_USB_POWER);
  bsp_init_ports(BSP_INIT_USB_POWER);
  bsp_init_timers(BSP_INIT_USB_POWER);
  bsp_init_output_compare(BSP_INIT_USB_POWER);
  bsp_init_i2c2(BSP_INIT_USB_POWER);
  bsp_init_spi2(BSP_INIT_USB_POWER);
  bsp_init_uart(BSP_INIT_USB_POWER);

  core_power_mode = CORE_USB_POWER;
}

void core_switch_to_usb_power()
{
  if(core_power_mode != CORE_USB_POWER)
  {
    core_power_mode = CORE_USB_POWER;
  }
}