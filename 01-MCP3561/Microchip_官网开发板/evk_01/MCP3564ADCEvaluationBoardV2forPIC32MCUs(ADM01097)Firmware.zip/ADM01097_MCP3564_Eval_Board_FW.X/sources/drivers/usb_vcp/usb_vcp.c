/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "usb_vcp.h"
#include <usb.h>
#include <usb_config.h>
#include <usb_device.h>
#include <usb_function_cdc.h>
#include <assert.h>

#define true    1
#define false   0
typedef char bool;

#define USB_VCP_SCHED_WRITE_BUFFER_SIZE     512

static uint8_t usb_vcp_read_buffer[CDC_DATA_OUT_EP_SIZE];
static uint8_t usb_vcp_write_buffer[CDC_DATA_IN_EP_SIZE];

static uint8_t usb_vcp_sched_write_buffer[USB_VCP_SCHED_WRITE_BUFFER_SIZE];
static uint16_t usb_vcp_sched_write_in;
static uint16_t usb_vcp_sched_write_out;

static enum
{
  USB_VCP_STATE_OFF = 0,
  USB_VCP_STATE_TURN_ON,
  USB_VCP_STATE_RUN,
  USB_VCP_STATE_TURN_OFF,
} usb_vcp_state;

static void(*usb_vcp_on_rx_received)(const char c);

void usb_vcp_init()
{
  usb_vcp_state = USB_VCP_STATE_OFF;
  usb_vcp_on_rx_received = NULL;
  usb_vcp_sched_write_in = 0;
  usb_vcp_sched_write_out = 0;
}

void usb_vcp_main_loop()
{
  switch(usb_vcp_state)
  {
    case USB_VCP_STATE_OFF:
    {

    } break;

    case USB_VCP_STATE_TURN_ON:
    {
      USBDeviceInit();
      USBDeviceAttach();

      usb_vcp_state = USB_VCP_STATE_RUN;
    } break;
    
    case USB_VCP_STATE_RUN:
    {
      uint8_t i;
      uint8_t numBytesRead;
      
      /* If the USB device isn't configured yet, we can't really do anything
        * else since we don't have a host to talk to.  So jump back to the
        * top of the while loop. */
      if( USBGetDeviceState() < CONFIGURED_STATE )
      {
        return;
      }

      /* If we are currently suspended, then we need to see if we need to
        * issue a remote wakeup.  In either case, we shouldn't process any
        * keyboard commands since we aren't currently communicating to the host
        * thus just continue back to the start of the while loop. */
      if( USBIsDeviceSuspended() == true )
      {
        return;
      }

      numBytesRead = getsUSBUSART(usb_vcp_read_buffer, sizeof(usb_vcp_read_buffer));

      /* For every byte that was read... */
      if(usb_vcp_on_rx_received)
      {
        for(i = 0; i < numBytesRead; i++)
        {
          usb_vcp_on_rx_received(usb_vcp_read_buffer[i]);
        }
      }

      if(USBUSARTIsTxTrfReady() == true)
      {
        if(usb_vcp_sched_write_in != usb_vcp_sched_write_out)
        {
          i = 0;
          while((i < CDC_DATA_IN_EP_SIZE) && (usb_vcp_sched_write_in != usb_vcp_sched_write_out))
          {
            usb_vcp_write_buffer[i] = usb_vcp_sched_write_buffer[usb_vcp_sched_write_out];
            
            usb_vcp_sched_write_out++;
            if(usb_vcp_sched_write_out >= USB_VCP_SCHED_WRITE_BUFFER_SIZE)
            {
              usb_vcp_sched_write_out = 0;
            }

            i++;
          }
          
          putUSBUSART(usb_vcp_write_buffer, i);
        }
      }

      CDCTxService();
    } break;

    case USB_VCP_STATE_TURN_OFF:
    {

    } break;

    default:
      assert(0);
      break;
  }
}

void usb_vcp_turn_on()
{
  if(usb_vcp_state == USB_VCP_STATE_OFF)
    usb_vcp_state = USB_VCP_STATE_TURN_ON;
}

void usb_vcp_turn_off()
{
  if(usb_vcp_state != USB_VCP_STATE_OFF)
    usb_vcp_state = USB_VCP_STATE_TURN_OFF;
}

//called by mla_usb. in interrupt context
BOOL USER_USB_CALLBACK_EVENT_HANDLER(int event, void *pdata, WORD size)
{
    switch( event )
    {
        case EVENT_TRANSFER:
            //Add application specific callback task or callback function here if desired.
            break;
        case EVENT_SOF:
            // USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            // USBCBSuspend();
            break;
        case EVENT_RESUME:
            // USBCBWakeFromSuspend();
            break;
        case EVENT_CONFIGURED: 
            CDCInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            ///USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCheckCDCRequest();
            break;
        case EVENT_BUS_ERROR:
            //USBCBErrorHandler();
            break;
        case EVENT_TRANSFER_TERMINATED:
            //Add application specific callback task or callback function here if desired.
            //The EVENT_TRANSFER_TERMINATED event occurs when the host performs a CLEAR
            //FEATURE (endpoint halt) request on an application endpoint which was 
            //previously armed (UOWN was = 1).  Here would be a good place to:
            //1.  Determine which endpoint the transaction that just got terminated was 
            //      on, by checking the handle value in the *pdata.
            //2.  Re-arm the endpoint if desired (typically would be the case for OUT 
            //      endpoints).
            break;
        default:
            break;
    }      
    return TRUE; 
}

uint8_t usb_vcp_ready()
{
  return ((usb_vcp_state == USB_VCP_STATE_RUN) && USBUSARTIsTxTrfReady());
}

uint8_t usb_vcp_send(const char *s, const uint8_t l)
{
  uint8_t i;

  assert(s != NULL);

  if(l > 0)
  {
    if(USBUSARTIsTxTrfReady() == true)
    {
      for(i = 0; i < l; i++)
        usb_vcp_write_buffer[i] = s[i];
      putUSBUSART(usb_vcp_write_buffer, l);
      
      return true;
    }
  }
  return false;
}

uint8_t usb_vcp_schedule_send(const char *s, const uint16_t l)
{
  uint16_t i = 0;
  while(i < l)
  {
    usb_vcp_sched_write_buffer[usb_vcp_sched_write_in] = s[i];
    usb_vcp_sched_write_in++;
    if(usb_vcp_sched_write_in >= USB_VCP_SCHED_WRITE_BUFFER_SIZE)
    {
      usb_vcp_sched_write_in = 0;
    }
    i++;
  }
  return true;
}

uint8_t usb_vcp_schedule_send_empty()
{
  return (usb_vcp_sched_write_in == usb_vcp_sched_write_out);
}

void usb_vcp_enable_rx_callback(void(*f)(const char c))
{
  usb_vcp_on_rx_received = f;
}

int USB_RX_READY ()
{
    
    if (usb_vcp_ready())//( USBUSARTIsTxTrfReady() == true)
    return 1;
    else   // if (usb_vcp_ready()) //( USBUSARTIsTxTrfReady() != true)
    return 0;
}