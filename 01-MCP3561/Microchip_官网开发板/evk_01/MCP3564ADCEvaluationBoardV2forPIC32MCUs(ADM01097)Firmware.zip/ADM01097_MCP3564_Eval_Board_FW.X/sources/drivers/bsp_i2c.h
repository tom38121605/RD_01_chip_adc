/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#pragma once

#include "bsp.h"

void bsp_init_i2c2(const uint8_t mode);

uint8_t bsp_i2c2_get_lock();
void bsp_i2c2_release_lock();
uint8_t bsp_i2c2_is_locked();

void bsp_i2c2_read_mem(const uint8_t i2c_addr, const uint8_t reg, const uint8_t len, uint8_t *buffer);
void bsp_i2c2_write_mem(const uint8_t i2c_addr, const uint8_t reg, const uint8_t len, const uint8_t *buffer);
void bsp_i2c2_read(const uint8_t i2c_addr, const uint8_t len, uint8_t *buffer);
void bsp_i2c2_write(const uint8_t i2c_addr, const uint8_t len, const uint8_t *buffer);
uint8_t bsp_i2c2_is_busy();

void bsp_i2c2_isr();