/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "uart_buffer.h"
#include "uart_buffer_internal.h"
#include <stddef.h> //for NULL
#include <assert.h>

#define UART_BUFFER_TX_LENGTH     1024

static void(*uart_buffer_on_rx)(const char c);                                      
static uint8_t uart_buffer_tx[UART_BUFFER_TX_LENGTH];
static uint16_t uart_buffer_tx_in;
static uint16_t uart_buffer_tx_out;

void uart_buffer_hw_on_rx(const uint8_t c)
{  
  if(uart_buffer_on_rx)
  {
    uart_buffer_on_rx(c);
  }
} 

uint8_t uart_buffer_hw_on_tx(uint8_t *c)
{
  if(uart_buffer_tx_in == uart_buffer_tx_out)
  {
    return 0;
  }
  else
  {
    *c = uart_buffer_tx[uart_buffer_tx_out];
    uart_buffer_tx_out++;
    if(uart_buffer_tx_out >= UART_BUFFER_TX_LENGTH)
    {
      uart_buffer_tx_out = 0;
    }
    return 1;
  }
}

void uart_buffer_init()
{
  uart_buffer_on_rx = NULL;
  uart_buffer_tx_in = 0;
  uart_buffer_tx_out = 0;
}

uint8_t uart_buffer_schedule_send(const char *s, const uint16_t l)
{
  uint16_t i = 0;
  uint8_t c;
  while(i < l)
  {
    uart_buffer_tx[uart_buffer_tx_in] = s[i];
    uart_buffer_tx_in++;
    if(uart_buffer_tx_in >= UART_BUFFER_TX_LENGTH)
    {
      uart_buffer_tx_in = 0;
    }

    i++;
  }

  if(uart_buffer_hw_tx_ready())
  {
    c = uart_buffer_tx[uart_buffer_tx_out];
    uart_buffer_tx_out++;
    if(uart_buffer_tx_out >= UART_BUFFER_TX_LENGTH)
    {
      uart_buffer_tx_out = 0;
    }

    uart_buffer_hw_transmit(c);
  }
  
  return 1;
}

uint8_t uart_buffer_schedule_send_empty()
{
  return (uart_buffer_tx_in == uart_buffer_tx_out);
}

void uart_buffer_enable_rx_callback(void(*f)(const char c))
{
  uart_buffer_on_rx = f;
}