/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#pragma once
#include <p32xxxx.h>
#include <sys/attribs.h>
#include <xc.h>
#include <plib.h>
#include <stdint.h>

#define PORT_DIR_INPUT      1
#define PORT_DIR_OUTPUT     0
#define PORT_SEL_DIGITAL    0
#define PORT_SEL_ANALOG     1

#define SWITCH_PRESSED      0
#define SW2                 _RD11
#define SW3                 _RD12
#define SW4                 _RD13
#define SW2_DIR             _TRISD11
#define SW3_DIR             _TRISD12
#define SW4_DIR             _TRISD13

#define LED_ON              1
#define LED_OFF             0

#define SW_DP               1
#define SW_VREF             0

#define IC_SW                _LATA4
#define LED3                _LATD4
#define LED4                _LATD5
#define IC_SW_DIR           _TRISA4
#define LED3_DIR            _TRISD4
#define LED4_DIR            _TRISD5

#define UART_RX_DIR         _TRISF4
#define UART_TX_DIR         _TRISF5

#define SDA2_DIR            _TRISA3
#define SCL2_DIR            _TRISA2
#define SDA2                _LATA3
#define SCL2                _LATA2

#define ADC_CLOCK           _LATD3
#define ADC_DATA_READY      _RE8
#define ADC_CLOCK_DIR       _TRISD3
#define ADC_DATA_READY_DIR  _TRISE8

#define DP_CS               _LATA5
#define ADC_CS              _LATG9
#define ADC_SCLK            _LATG6
#define ADC_MOSI            _LATG8
#define ADC_MISO            _LATG7
#define DP_CS_DIR           _TRISA5
#define ADC_CS_DIR          _TRISG9
#define ADC_SCLK_DIR        _TRISG6
#define ADC_MOSI_DIR        _TRISG8
#define ADC_MISO_DIR        _TRISG7

#define I2C_FREQUENCY       100000
#define UART_BAUDRATE       460800
//#define UART_BAUDRATE       921600
#define TIMER3_FREQUENCY    10
#define TIMER1_FREQUENCY    1


/* Do not modify below this line */

#define BSP_INIT_USB_POWER          1

void bsp_init_cpu(const uint8_t mode);
void bsp_init_ports(const uint8_t mode);
void bsp_init_timers(const uint8_t mode);
void bsp_init_output_compare(const uint8_t mode);
void bsp_init_spi2(const uint8_t mode);
void bsp_init_uart(const uint8_t mode);

#define CRYSTAL_FREQ        (uint32_t)8000000   //8 MHz
#define PLL_M               20
#define PLL_N               2

#define FOSC_PLL            (CRYSTAL_FREQ*PLL_M/PLL_N)
#define FCY_PLL             (FOSC_PLL / 2)

#define buffer_lenght       2048


void mcp41010_hw_write_data(uint32_t data); // temp
void set_sw_value(uint32_t value); //temp
void set_sampling_speed(uint32_t i); //temp
void disable_output_compare();
void set_new_osc_value(uint32_t i, uint8_t x, uint8_t y);
void reset_timer_2();


uint32_t PWM4_PR2  ;          
uint8_t PWM4_OC4R ;
uint8_t PWM4_OC4RS;