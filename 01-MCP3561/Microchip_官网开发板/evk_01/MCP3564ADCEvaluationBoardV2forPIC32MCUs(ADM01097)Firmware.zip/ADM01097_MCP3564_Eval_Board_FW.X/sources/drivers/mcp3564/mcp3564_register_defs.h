/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#pragma once

#define MCP3564_REGISTER_CONFIG0                                    0x01
#define MCP3564_REGISTER_CONFIG1                                    0x02
#define MCP3564_REGISTER_CONFIG2                                    0x03
#define MCP3564_REGISTER_CONFIG3                                    0x04
#define MCP3564_REGISTER_MUX                                        0x06
#define MCP3564_REGISTER_OFFSET                                     0x09
#define MCP3564_REGISTER_GAIN                                       0x0A

 //CONFIG0 //
#define MCP3564_REGISTER_CONFIG0_VREF_SEL_0                         0b00000000
#define MCP3564_REGISTER_CONFIG0_VREF_SEL_1                         0b01000000
#define MCP3564_REGISTER_CONFIG0_VREF_SEL_2                         0b10000000
#define MCP3564_REGISTER_CONFIG0_VREF_SEL_3                         0b11000000
    
#define MCP3564_REGISTER_CONFIG0_CLK_SEL_0                          0b00000000
#define MCP3564_REGISTER_CONFIG0_CLK_SEL_1                          0b00010000
#define MCP3564_REGISTER_CONFIG0_CLK_SEL_2                          0b00100000
#define MCP3564_REGISTER_CONFIG0_CLK_SEL_3                          0b00110000

#define MCP3564_REGISTER_CONFIG0_CS_SEL_0                           0b00000000
#define MCP3564_REGISTER_CONFIG0_CS_SEL_1                           0b00000100
#define MCP3564_REGISTER_CONFIG0_CS_SEL_2                           0b00001000
#define MCP3564_REGISTER_CONFIG0_CS_SEL_3                           0b00001100

#define MCP3564_REGISTER_CONFIG0_MODE_SHUTDOWN_DEFAULT              0b00000000
#define MCP3564_REGISTER_CONFIG0_MODE_SHUTDOWN                      0b00000001
#define MCP3564_REGISTER_CONFIG0_MODE_STANDBY                       0b00000010
#define MCP3564_REGISTER_CONFIG0_MODE_CONVERSION                    0b00000011
    
 //CONFIG1 //
#define MCP3564_REGISTER_CONFIG1_PRE_1                              0b00000000    
#define MCP3564_REGISTER_CONFIG1_PRE_2                              0b01000000   
#define MCP3564_REGISTER_CONFIG1_PRE_4                              0b10000000   
#define MCP3564_REGISTER_CONFIG1_PRE_8                              0b11000000   
    
#define MCP3564_REGISTER_CONFIG1_OSR_98304                          0b00111100
#define MCP3564_REGISTER_CONFIG1_OSR_81920                          0b00111000
#define MCP3564_REGISTER_CONFIG1_OSR_49152                          0b00110100
#define MCP3564_REGISTER_CONFIG1_OSR_40960                          0b00110000
#define MCP3564_REGISTER_CONFIG1_OSR_24576                          0b00101100
#define MCP3564_REGISTER_CONFIG1_OSR_20480                          0b00101000
#define MCP3564_REGISTER_CONFIG1_OSR_16384                          0b00100100
#define MCP3564_REGISTER_CONFIG1_OSR_8192                           0b00100000
#define MCP3564_REGISTER_CONFIG1_OSR_4096                           0b00011100
#define MCP3564_REGISTER_CONFIG1_OSR_2048                           0b00011000
#define MCP3564_REGISTER_CONFIG1_OSR_1024                           0b00010100
#define MCP3564_REGISTER_CONFIG1_OSR_512                            0b00010000
#define MCP3564_REGISTER_CONFIG1_OSR_256                            0b00001100
#define MCP3564_REGISTER_CONFIG1_OSR_128                            0b00001000
#define MCP3564_REGISTER_CONFIG1_OSR_64                             0b00000100
#define MCP3564_REGISTER_CONFIG1_OSR_32                             0b00000000
      
#define MCP3564_REGISTER_CONFIG1_DITHER_MAX                         0b00000011  
#define MCP3564_REGISTER_CONFIG1_DITHER_MED                         0b00000010
#define MCP3564_REGISTER_CONFIG1_DITHER_MIN                         0b00000001
#define MCP3564_REGISTER_CONFIG1_DITHER_DEF                         0b00000000
    
 //CONFIG2 // 
#define MCP3564_REGISTER_CONFIG2_BOOST_x2                           0b11000000
#define MCP3564_REGISTER_CONFIG2_BOOST_x1                           0b10000000 //DEFAULT
#define MCP3564_REGISTER_CONFIG2_BOOST_x066                         0b01000000 //x0.66
#define MCP3564_REGISTER_CONFIG2_BOOST_x05                          0b00000000 //x0.5
    
#define MCP3564_REGISTER_CONFIG2_GAIN_x64                           0b00111000
#define MCP3564_REGISTER_CONFIG2_GAIN_x32                           0b00110000
#define MCP3564_REGISTER_CONFIG2_GAIN_x16                           0b00101000
#define MCP3564_REGISTER_CONFIG2_GAIN_x8                            0b00100000
#define MCP3564_REGISTER_CONFIG2_GAIN_x4                            0b00011000
#define MCP3564_REGISTER_CONFIG2_GAIN_x2                            0b00010000
#define MCP3564_REGISTER_CONFIG2_GAIN_x1                            0b00001000 //DEFAULT
#define MCP3564_REGISTER_CONFIG2_GAIN_x033                          0b00000000 //x1/3

#define MCP3564_REGISTER_CONFIG2_AZ_MUX_EN                          0b00000100
#define MCP3564_REGISTER_CONFIG2_AZ_MUX_DIS                         0b00000000

#define MCP3564_REGISTER_CONFIG2_AZ_VREF_EN                         0b00000010
#define MCP3564_REGISTER_CONFIG2_AZ_VREF_DIS                        0b00000000
    
#define MCP3564_REGISTER_CONFIG2_AZ_FREQ_HIGH                       0b00000001
#define MCP3564_REGISTER_CONFIG2_AZ_FREQ_LOW                        0b00000000
    
//CONFIG3 // 
#define MCP3564_REGISTER_CONFIG3_CONV_MODE_CONT                     0b11000000
#define MCP3564_REGISTER_CONFIG3_CONV_MODE_STANDBY                  0b10000000
#define MCP3564_REGISTER_CONFIG3_CONV_MODE_SHUTDOWN                 0b01000000
#define MCP3564_REGISTER_CONFIG3_CONV_MODE_SHUTDOWN0                0b00000000
    
#define MCP3564_REGISTER_CONFIG3_DATA_FORMAT_8STATUSB               0b00110000
#define MCP3564_REGISTER_CONFIG3_DATA_FORMAT_8SEXTENSION            0b00100000
#define MCP3564_REGISTER_CONFIG3_DATA_FORMAT_80                     0b00010000
#define MCP3564_REGISTER_CONFIG3_DATA_FORMAT_DEF                    0b00000000
    
#define MCP3564_REGISTER_CONFIG3_CRC_FORMAT_32                      0b00001000    
#define MCP3564_REGISTER_CONFIG3_CRC_FORMAT_16                      0b00000000  
    
#define MCP3564_REGISTER_CONFIG3_CRC_COM_EN                         0b00000100
#define MCP3564_REGISTER_CONFIG3_CRC_COM_DIS                        0b00000000  
    
#define MCP3564_REGISTER_CONFIG3_CRC_OFFCAL_EN                      0b00000010  
#define MCP3564_REGISTER_CONFIG3_CRC_OFFCAL_DIS                     0b00000000 
    
#define MCP3564_REGISTER_CONFIG3_CRC_GAINCAL_EN                     0b00000001 
#define MCP3564_REGISTER_CONFIG3_CRC_GAINCAL_DIS                    0b00000000
  
// IRQ REGISTER // 
#define MCP3564_REGISTER_IRQ_MODE_MDAT                              0b00001000
#define MCP3564_REGISTER_IRQ_MODE_IRQ                               0b00000000
#define MCP3564_REGISTER_IRQ_MODE_logicHIGH                         0b00000100
#define MCP3564_REGISTER_IRQ_MODE_HIGHZ                             0b00000000
    
#define MCP3564_REGISTER_IRQ_FASTCMD_EN                             0b00000010
#define MCP3564_REGISTER_IRQ_FASTCMD_DIS                            0b00000000
    
#define MCP3564_REGISTER_IRQ_STP_EN                                 0b00000001
#define MCP3564_REGISTER_IRQ_STP_DIS                                0b00000000

// MUX REGISTER //
#define MCP3564_REGISTER_MUX_VIN_PLUS_NoINPUT                       0b11110000
#define MCP3564_REGISTER_MUX_VIN_PLUS_VCM                           0b11100000
#define MCP3564_REGISTER_MUX_VIN_PLUS_TEMP                          0b11010000
#define MCP3564_REGISTER_MUX_VIN_PLUS_VrefExtMinus                  0b11000000
#define MCP3564_REGISTER_MUX_VIN_PLUS_VrefExtPlus                   0b10110000
#define MCP3564_REGISTER_MUX_VIN_PLUS_VrefInt                       0b10100000
#define MCP3564_REGISTER_MUX_VIN_PLUS_AVDD                          0b10010000
#define MCP3564_REGISTER_MUX_VIN_PLUS_VSS                           0b10000000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH7                           0b01110000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH6                           0b01100000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH5                           0b01010000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH4                           0b01000000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH3                           0b00110000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH2                           0b00100000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH1                           0b00010000
#define MCP3564_REGISTER_MUX_VIN_PLUS_CH0                           0b00000000

#define MCP3564_REGISTER_MUX_VIN_MINUS_NoINPUT                      0b00001111
#define MCP3564_REGISTER_MUX_VIN_MINUS_VCM                          0b00001110
#define MCP3564_REGISTER_MUX_VIN_MINUS_TEMP                         0b00001101
#define MCP3564_REGISTER_MUX_VIN_MINUS_VrefExtMinus                 0b00001100
#define MCP3564_REGISTER_MUX_VIN_MINUS_VrefExtPlus                  0b00001011
#define MCP3564_REGISTER_MUX_VIN_MINUS_VrefInt                      0b00001010
#define MCP3564_REGISTER_MUX_VIN_MINUS_AVDD                         0b00001001
#define MCP3564_REGISTER_MUX_VIN_MINUS_VSS                          0b00001000
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH7                          0b00000111
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH6                          0b00000110
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH5                          0b00000101
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH4                          0b00000100
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH3                          0b00000011
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH2                          0b00000010
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH1                          0b00000001
#define MCP3564_REGISTER_MUX_VIN_MINUS_CH0                          0b00000000
    
// SCAN REGISTER //
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx512                         0b111000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx256                         0b110000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx128                         0b101000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx64                          0b100000000000000000000000  
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx32                          0b011000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx16                          0b010000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_DMCLKx8                           0b001000000000000000000000
#define MCP3564_REGISTER_SCAN_DLY_NoDELAY                           0b000000000000000000000000
  
#define MCP3564_REGISTER_SCAN_PSAV_VREF_OFF                         0b000100000000000000000000
#define MCP3564_REGISTER_SCAN_PSAV_VREF_ON                          0b000000000000000000000000

#define MCP3564_REGISTER_SCAN_OFFSET                                0b000000001000000000000000
#define MCP3564_REGISTER_SCAN_VREF                                  0b000000000100000000000000
#define MCP3564_REGISTER_SCAN_AVDD                                  0b000000000010000000000000
#define MCP3564_REGISTER_SCAN_TEMP                                  0b000000000001000000000000
#define MCP3564_REGISTER_SCAN_DIFF_D                                0b000000000000100000000000
#define MCP3564_REGISTER_SCAN_DIFF_C                                0b000000000000010000000000
#define MCP3564_REGISTER_SCAN_DIFF_B                                0b000000000000001000000000
#define MCP3564_REGISTER_SCAN_DIFF_A                                0b000000000000000100000000
#define MCP3564_REGISTER_SCAN_CH7                                   0b000000000000000010000000
#define MCP3564_REGISTER_SCAN_CH6                                   0b000000000000000001000000
#define MCP3564_REGISTER_SCAN_CH5                                   0b000000000000000000100000
#define MCP3564_REGISTER_SCAN_CH4                                   0b000000000000000000010000
#define MCP3564_REGISTER_SCAN_CH3                                   0b000000000000000000001000
#define MCP3564_REGISTER_SCAN_CH2                                   0b000000000000000000000100
#define MCP3564_REGISTER_SCAN_CH1                                   0b000000000000000000000010
#define MCP3564_REGISTER_SCAN_CH0                                   0b000000000000000000000001