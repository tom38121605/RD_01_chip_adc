/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "mcp3564.h"
#include "mcp3564_internal.h"
#include "mcp3564_register_defs.h"
#include <stddef.h>
#include <assert.h>

uint32_t mcp3564_data;
static uint8_t mcp3564_in_state;
static uint8_t mcp3564_data_ready;
static uint8_t mcp3564_must_turn_off;
static uint8_t mcp3564_must_write_registers;
static uint8_t mcp3564_must_read_registers;

static uint8_t mcp3564_pga_value;
static int32_t mcp3564_offset_value;
static uint32_t mcp3564_gain_value;

static uint8_t mcp3564_new_pga_value;
static int32_t mcp3564_new_offset_value;
static uint32_t mcp3564_new_gain_value;

static uint8_t mcp3564_read_buffer[4];                                          
static int32_t mcp3564_new_value;
static void(*mcp3564_on_new_value)(const int32_t new_value);
static void(*mcp3564_write_on_finish)();
static void(*mcp3564_read_on_finish)(const uint32_t *registers);

static uint32_t mcp3564_registers[15];
static uint8_t mcp3564_current_register;
static uint8_t mcp3564_current_register_index;

static enum
{
  MCP3564_STATE_OFF = 0,
  MCP3564_STATE_TURN_ON,
  MCP3564_STATE_IDLE,
  MCP3564_STATE_READ,
  MCP3564_STATE_SET_PGA,
  MCP3564_STATE_SET_OFFSET,
  MCP3564_STATE_SET_GAIN,
  MCP3564_STATE_TURN_OFF,

  MCP3564_STATE_WRITE_REGISTERS,
  MCP3564_STATE_READ_REGISTERS,
} mcp3564_state;

static uint8_t mcp3564_register_get_length(const uint8_t register_address)
{
  switch(register_address)
  {
    case 0x00:
      return 4;
    case 0x07:
    case 0x08:
    case 0x09:
    case 0x0A:
    case 0x0F:
      return 3;
    break;
    case 0x0B:
    case 0x0E:
      return 2;
    break;
    case 0x01:
    case 0x02:
    case 0x03:
    case 0x04:
    case 0x05:
    case 0x06:
    case 0x0C:
    case 0x0D:
      return 1;
    break;

    default:
      assert(0);
    break;
  }
  return 0;
}

void mcp3564_on_data_ready()
{
  mcp3564_data_ready = 1;
}

void mcp3564_init()
{
  mcp3564_state = MCP3564_STATE_OFF;
  mcp3564_must_turn_off = 0;
  mcp3564_in_state = 0;
  mcp3564_data_ready = 1; //make first reading anyway
  mcp3564_on_new_value = NULL;

  mcp3564_pga_value = MCP3564_REGISTER_CONFIG2_GAIN_x64;
  mcp3564_offset_value = 0;
  mcp3564_gain_value = 0x800000;

  mcp3564_new_pga_value = mcp3564_pga_value;
  mcp3564_new_offset_value = mcp3564_offset_value;
  mcp3564_new_gain_value = mcp3564_gain_value;
}

void mcp3564_main_loop()
{
  switch(mcp3564_state)
  {
    case MCP3564_STATE_OFF:
    {
    } break;

    case MCP3564_STATE_TURN_ON:
    {
      switch(mcp3564_in_state)
      {
        case 0:
          if(mcp3564_hw_ready())
          {
            uint8_t data = MCP3564_REGISTER_CONFIG0_VREF_SEL_0 | MCP3564_REGISTER_CONFIG0_CLK_SEL_0 | MCP3564_REGISTER_CONFIG0_CS_SEL_0 | MCP3564_REGISTER_CONFIG0_MODE_CONVERSION;
            mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG0, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG0), &data);
            mcp3564_in_state++;
          }
        break;

        case 1:
          if(mcp3564_hw_ready())
          {
            uint8_t data = MCP3564_REGISTER_CONFIG1_PRE_1 | MCP3564_REGISTER_CONFIG1_OSR_98304 | MCP3564_REGISTER_CONFIG1_DITHER_DEF;
            mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG1, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG1), &data);
            mcp3564_in_state++;
          }
        break;

        case 2:
          if(mcp3564_hw_ready())
          {
            uint8_t data = MCP3564_REGISTER_CONFIG2_BOOST_x1 | mcp3564_pga_value | MCP3564_REGISTER_CONFIG2_AZ_MUX_DIS | MCP3564_REGISTER_CONFIG2_AZ_VREF_EN | MCP3564_REGISTER_CONFIG2_AZ_FREQ_HIGH;
            mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG2, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG2), &data);
            mcp3564_in_state++;
          }
        break;

        case 3:
          if(mcp3564_hw_ready())
          {
            uint8_t data = MCP3564_REGISTER_CONFIG3_CONV_MODE_CONT | MCP3564_REGISTER_CONFIG3_DATA_FORMAT_8STATUSB | MCP3564_REGISTER_CONFIG3_CRC_FORMAT_16 | MCP3564_REGISTER_CONFIG3_CRC_COM_DIS | MCP3564_REGISTER_CONFIG3_CRC_OFFCAL_EN | MCP3564_REGISTER_CONFIG3_CRC_GAINCAL_EN;
            mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG3, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG3), &data);
            mcp3564_in_state++;
          }
        break;

        case 4:
          if(mcp3564_hw_ready())
          {
            uint8_t data = MCP3564_REGISTER_MUX_VIN_PLUS_CH0 | MCP3564_REGISTER_MUX_VIN_MINUS_CH1;
            mcp3564_hw_write_data(MCP3564_REGISTER_MUX, mcp3564_register_get_length(MCP3564_REGISTER_MUX), &data);
            mcp3564_in_state++;
          }
        break;

        case 5:
          if(mcp3564_hw_ready())
          {
            uint32_t data = mcp3564_offset_value;
            mcp3564_hw_write_data(MCP3564_REGISTER_OFFSET, mcp3564_register_get_length(MCP3564_REGISTER_OFFSET), &data);
            mcp3564_in_state++;
          }
        break;

        case 6:
          if(mcp3564_hw_ready())
          {
            uint32_t data = mcp3564_gain_value;
            mcp3564_hw_write_data(MCP3564_REGISTER_GAIN, mcp3564_register_get_length(MCP3564_REGISTER_GAIN), &data);
            mcp3564_in_state++;
          }
        break;

        case 7:
          if(mcp3564_hw_ready())
          {
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0; 
          }
        break;

        default:
          assert(0);
        break;
      }     
    } break;

    case MCP3564_STATE_IDLE:
    {
      if(mcp3564_data_ready)
      {
        mcp3564_data_ready = 0;
        mcp3564_state = MCP3564_STATE_READ;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_new_pga_value != mcp3564_pga_value)
      {
        mcp3564_state = MCP3564_STATE_SET_PGA;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_new_offset_value != mcp3564_offset_value)
      {
        mcp3564_state = MCP3564_STATE_SET_OFFSET;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_new_gain_value != mcp3564_gain_value)
      {
        mcp3564_state = MCP3564_STATE_SET_GAIN;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_must_turn_off)
      {
        mcp3564_must_turn_off = 0;
        mcp3564_state = MCP3564_STATE_TURN_OFF;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_must_write_registers)
      {
        mcp3564_must_write_registers = 0;
        mcp3564_state = MCP3564_STATE_WRITE_REGISTERS;
        mcp3564_in_state = 0;
      }
      else
      if(mcp3564_must_read_registers)
      {
        mcp3564_must_read_registers = 0;
        mcp3564_state = MCP3564_STATE_READ_REGISTERS;
        mcp3564_in_state = 0;
      }
    } break;

    case MCP3564_STATE_READ:
    {
      switch(mcp3564_in_state)
      {
        case 0:
          mcp3564_hw_read_data(0x00, mcp3564_register_get_length(0x00), mcp3564_read_buffer); 
          mcp3564_in_state++;
          break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_new_value = *(int32_t*)mcp3564_read_buffer;

            if(mcp3564_on_new_value)                                             
              mcp3564_on_new_value(mcp3564_new_value);
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
          break;
        
        default:
          assert(0);
          break;
      }
    } break;

    case MCP3564_STATE_SET_PGA:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          uint8_t data = MCP3564_REGISTER_CONFIG2_BOOST_x1 | mcp3564_new_pga_value | MCP3564_REGISTER_CONFIG2_AZ_MUX_DIS | MCP3564_REGISTER_CONFIG2_AZ_VREF_EN | MCP3564_REGISTER_CONFIG2_AZ_FREQ_HIGH;
          mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG2, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG2), &data);
          mcp3564_in_state++;
        } break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_pga_value = mcp3564_new_pga_value;
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
          break;
        
        default:
          assert(0);
          break;
      }
    } break;

    case MCP3564_STATE_SET_OFFSET:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          
          uint32_t data = (uint32_t)mcp3564_new_offset_value;
          mcp3564_hw_write_data(MCP3564_REGISTER_OFFSET, mcp3564_register_get_length(MCP3564_REGISTER_OFFSET), &data);
          mcp3564_in_state++;
        } break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_offset_value = mcp3564_new_offset_value;
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
          break;
        
        default:
          assert(0);
          break;
      }
    } break;

    case MCP3564_STATE_SET_GAIN:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          uint32_t data = mcp3564_new_gain_value;
          mcp3564_hw_write_data(MCP3564_REGISTER_GAIN, mcp3564_register_get_length(MCP3564_REGISTER_GAIN), &data);
          mcp3564_in_state++;
        }break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_gain_value = mcp3564_new_gain_value;
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
        break;
        
        default:
          assert(0);
        break;
      }
    } break;

    case MCP3564_STATE_TURN_OFF:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          uint8_t data = MCP3564_REGISTER_CONFIG0_VREF_SEL_3 | MCP3564_REGISTER_CONFIG0_CLK_SEL_0 | MCP3564_REGISTER_CONFIG0_CS_SEL_0 | MCP3564_REGISTER_CONFIG0_MODE_SHUTDOWN;
          mcp3564_hw_write_data(MCP3564_REGISTER_CONFIG0, mcp3564_register_get_length(MCP3564_REGISTER_CONFIG0), &data);
          mcp3564_in_state++;
        }break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_hw_turn_off();
            mcp3564_state = MCP3564_STATE_OFF;
            mcp3564_in_state = 0;
          }
        break;
        
        default:
          assert(0);
        break;
      }
    } break;

    case MCP3564_STATE_WRITE_REGISTERS:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          mcp3564_current_register = 0x01;
          mcp3564_current_register_index = 0;
          mcp3564_in_state++;
        } break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_hw_write_data(mcp3564_current_register, mcp3564_register_get_length(mcp3564_current_register), &mcp3564_registers[mcp3564_current_register_index]);
            mcp3564_current_register++;
 
            if(mcp3564_current_register > 0x0A)                                 // skip the OSCCAL reg (0x0B)
            {
              mcp3564_current_register++;
            }
            
            mcp3564_current_register_index++;

            if(mcp3564_current_register > 0x0D)                                 // write all registers till LOCK (0x0D)
            {
              mcp3564_in_state++;
            }
          }
        break;

        case 2:
          if(mcp3564_hw_ready())
          {
            if(mcp3564_write_on_finish)
            {
              mcp3564_write_on_finish();
            }
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
        break;
        
        default:
          assert(0);
          break;
      }
    } break;

    case MCP3564_STATE_READ_REGISTERS:
    {
      switch(mcp3564_in_state)
      {
        case 0:
        {
          mcp3564_current_register = 0x01;
          mcp3564_current_register_index = 0;
          mcp3564_in_state++;
        } break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp3564_hw_read_data(mcp3564_current_register, mcp3564_register_get_length(mcp3564_current_register), &mcp3564_registers[mcp3564_current_register_index]);
            mcp3564_current_register++;
            if(mcp3564_current_register == 0x0E)
            {
              mcp3564_current_register++;
            }
            mcp3564_current_register_index++;

            if(mcp3564_current_register > 0x0F)
            {
              mcp3564_in_state++;
            }
          }
        break;

        case 2:
          if(mcp3564_hw_ready())
          {
            if(mcp3564_read_on_finish)
            {
              mcp3564_read_on_finish(mcp3564_registers);
            }
            mcp3564_state = MCP3564_STATE_IDLE;
            mcp3564_in_state = 0;
          }
        break;
        
        default:
          assert(0);
        break;
      }
    } break;

    default:
      assert(0);
    break;
  } 
}

void mcp3564_turn_on()
{
  if(mcp3564_state == MCP3564_STATE_OFF)
  {
    mcp3564_hw_turn_on();
    mcp3564_state = MCP3564_STATE_TURN_ON;
    mcp3564_in_state = 0;
  }
}

void mcp3564_turn_off()
{
  mcp3564_must_turn_off = 1;
}

void mcp3564_enable_callback(void(*f)(const int32_t new_value))
{
  mcp3564_on_new_value = f;
}

void new_value(void(*f)(const int32_t new_value))
{
  mcp3564_on_new_value = f;
}

uint8_t mcp3564_is_ready()
{
  return(mcp3564_state == MCP3564_STATE_IDLE);
}

uint8_t mcp3564_is_on()
{
  return(mcp3564_state != MCP3564_STATE_OFF);
}

void mcp3564_set_pga(const uint8_t pga_value)
{
  mcp3564_new_pga_value = pga_value;
}

void mcp3564_set_offset(const int32_t offset_value)
{
  mcp3564_new_offset_value = offset_value;
}

void mcp3564_set_gain(const uint32_t gain_value)
{
  mcp3564_new_gain_value = gain_value;
}

void mcp3564_write_all_registers(const uint32_t *registers, void(*on_finish)())
{
  uint8_t i;
  mcp3564_write_on_finish = on_finish;
  mcp3564_must_write_registers = 1;
  
  for(i = 0; i < 15; i++)
  {
    mcp3564_registers[i] = registers[i];
  }
  
  set_sampling_speed(mcp3564_registers[10]);                                    // set sampling speed 
  set_sw_value(mcp3564_registers[13]);                                          // set Switch value
  mcp41010_hw_write_data(mcp3564_registers[14]);                                // send dp value
  
  if(mcp3564_state == MCP3564_STATE_OFF)
  {
    mcp3564_hw_turn_on();
    mcp3564_state = MCP3564_STATE_IDLE;
    mcp3564_in_state = 0;
  }
}

void mcp3564_read_all_registers(void(*on_finish)(const uint32_t *registers))
{
  mcp3564_read_on_finish = on_finish;
  mcp3564_must_read_registers = 1;

  if(mcp3564_state == MCP3564_STATE_OFF)
  {
    mcp3564_hw_turn_on();
    mcp3564_state = MCP3564_STATE_IDLE;
    mcp3564_in_state = 0;
  }
}

void read_data_()
{
  mcp3564_hw_read_data(0x00, mcp3564_register_get_length(0x00), mcp3564_read_buffer);
  mcp3564_new_value = *(int32_t*)mcp3564_read_buffer;
  mcp3564_on_new_value(mcp3564_new_value);
}