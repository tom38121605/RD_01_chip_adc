/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "mcp3564_internal.h"
#include "mcp3564.h"
#include "bsp.h"
#include <assert.h>

#define MCP3564_SLAVE_ADDRESS               0x01
#define MCP3564_COMMAND_WRITE               0x02
#define MCP3564_COMMAND_READ                0x03

static uint8_t spi_busy = 0;
static uint8_t spi_write_buffer[5];
static uint8_t spi_write_length;
static uint8_t *spi_read_buffer;
static uint8_t *spi_read_buffer_end;
static uint8_t spi_in_state = 0;

static enum
{
  SPI_STATE_IDLE = 0,
  SPI_STATE_READ,
  SPI_STATE_WRITE,
  SPI_STATE_FINISHED,
} spi_send_state;

static void mcp3564_spi_cs_on()
{
  ADC_CS = 0;
}

static void mcp3564_spi_cs_off()
{
  ADC_CS = 1;
}

void mcp3564_hw_turn_off()
{
  T2CONbits.TON = 0;
}

void mcp3564_hw_turn_on()
{
  T2CONbits.TON = 1;                                                            // Turn on timer for clock generation
}

uint8_t mcp3564_hw_ready()
{
  return (!spi_busy);
}

void mcp3564_hw_write_data(const uint8_t register_address, const uint8_t register_length, const void* data)
{
  uint8_t i;
  int8_t k;
  spi_busy = 0;
  
  SPI2CONbits.MODE16 = 0;         //  SPI_MODE16_OFF
  SPI2CONbits.MODE32 = 0;         //  SPI_MODE32_OFF
  mcp3564_spi_cs_on();
  spi_write_buffer[0] = (MCP3564_SLAVE_ADDRESS << 6) | ((register_address & 0x0F) << 2) | (MCP3564_COMMAND_WRITE & 0x03);
  i = SPI2BUF;
  SPI2BUF = spi_write_buffer[0];
  while(!SPI2STATbits.SPIRBF);
  i = 1;
  k = register_length - 1;
  while(k >= 0)
  {
    i = SPI2BUF;
    SPI2BUF = ((uint8_t*)data)[k];
    while(!SPI2STATbits.SPIRBF);
    k--;
  }
  i = SPI2BUF;
  mcp3564_spi_cs_off();
}

void mcp3564_hw_read_data(const uint8_t register_address, const uint8_t data_length, void* data)
{
  spi_busy = 0;
  
  mcp3564_spi_cs_on();
  switch(data_length)
  {
    case 1:
      SPI2CONbits.MODE16 = 1;
      SPI2CONbits.MODE32 = 0;
      spi_write_buffer[1] = (MCP3564_SLAVE_ADDRESS << 6) | ((register_address & 0x0F) << 2) | (MCP3564_COMMAND_READ & 0x03);
      spi_write_buffer[0] = 0;
      
      SPI2BUF = *(uint16_t*)spi_write_buffer;
      while(!SPI2STATbits.SPIRBF);
      *(uint16_t*)data = SPI2BUF;
    break;

    case 2:
      SPI2CONbits.MODE16 = 0;
      SPI2CONbits.MODE32 = 0;

      spi_write_buffer[2] = (MCP3564_SLAVE_ADDRESS << 6) | ((register_address & 0x0F) << 2) | (MCP3564_COMMAND_READ & 0x03);
      spi_write_buffer[1] = 0;
      spi_write_buffer[0] = 0;
      
      SPI2BUF = spi_write_buffer[0];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[2] = SPI2BUF;

      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[1] = SPI2BUF;

      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[0] = SPI2BUF;
    break;
      
    case 3:
      SPI2CONbits.MODE16 = 0;
      SPI2CONbits.MODE32 = 1;

      spi_write_buffer[3] = (MCP3564_SLAVE_ADDRESS << 6) | ((register_address & 0x0F) << 2) | (MCP3564_COMMAND_READ & 0x03);
      spi_write_buffer[2] = 0;
      spi_write_buffer[1] = 0;
      spi_write_buffer[0] = 0;

      SPI2BUF = *(uint32_t*)spi_write_buffer;
      while(!SPI2STATbits.SPIRBF);
      *(uint32_t*)data = SPI2BUF;                                                               
    break;
      
    case 4:
      SPI2CONbits.MODE16 = 0;
      SPI2CONbits.MODE32 = 0;

      spi_write_buffer[4] = (MCP3564_SLAVE_ADDRESS << 6) | ((register_address & 0x0F) << 2) | (MCP3564_COMMAND_READ & 0x03);
      spi_write_buffer[3] = 0;
      spi_write_buffer[2] = 0;
      spi_write_buffer[1] = 0;
      spi_write_buffer[0] = 0;
  
      SPI2BUF = spi_write_buffer[4];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[4] = SPI2BUF;
      
      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[3] = SPI2BUF;
      
      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[2] = SPI2BUF;

      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[1] = SPI2BUF;

      SPI2BUF = spi_write_buffer[1];
      while(!SPI2STATbits.SPIRBF);
      ((uint8_t*)data)[0] = SPI2BUF;
      break;
    break;
  }

  mcp3564_spi_cs_off();
}