/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "mcp41010.h"
#include "mcp41010_internal.h"
#include <stddef.h>
#include <assert.h>

static uint8_t mcp41010_in_state;
static uint8_t mcp41010_pot_value;
static uint8_t mcp41010_new_pot_value;

static enum
{
  MCP41010_STATE_OFF = 0,
  MCP41010_STATE_TURN_ON,
  MCP41010_STATE_IDLE,
  MCP41010_STATE_SET_POT,
  MCP41010_STATE_TURN_OFF,
} mcp41010_state;

void mcp41010_init()
{
  mcp41010_pot_value = 0xB0;
  mcp41010_new_pot_value = 0xB0;
}

void mcp41010_main_loop()
{
   
  switch(mcp41010_state)
  {
    case MCP41010_STATE_OFF:
    {
    } break;

    case MCP41010_STATE_TURN_ON:
    {   
    } break;

    case MCP41010_STATE_IDLE:
    {
    } break;

    case MCP41010_STATE_SET_POT:
    {
      switch(mcp41010_in_state)
      {
        case 0:
        {
          uint8_t data = 0xB0;
          mcp41010_hw_write_data(&data);
          mcp41010_in_state++;
        } break;

        case 1:
          if(mcp3564_hw_ready())
          {
            mcp41010_pot_value = mcp41010_new_pot_value;
            mcp41010_state = MCP41010_STATE_IDLE;
            mcp41010_in_state = 0;
          }
          break;
        
        default:
          assert(0);
          break;
      }
    } break;

    case MCP41010_STATE_TURN_OFF:
    {
     
    } break;

    default:
      assert(0);
      break;
  } 
}

void mcp41010_set_pot(const uint8_t pot_value)
{
  mcp41010_new_pot_value = pot_value;
}