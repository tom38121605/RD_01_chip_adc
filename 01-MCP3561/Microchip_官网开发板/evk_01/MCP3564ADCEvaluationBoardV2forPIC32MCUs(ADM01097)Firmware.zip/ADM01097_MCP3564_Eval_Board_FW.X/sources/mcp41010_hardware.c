/*
 * Copyright 2019 Microchip Technology Inc. and its subsidiaries.
 * 
 * Subject to your compliance with these terms, you may use Microchip software and 
 * any derivatives exclusively with Microchip products. It is your responsibility
 * to comply with third party license terms applicable to your use of third party 
 * software (including open source software) that may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, 
 * IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES 
 * OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
 * RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF 
 * THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY
 * LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE
 * WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP
 * FOR THIS SOFTWARE.                           
 * 
 */

#include "bsp.h"
#include <assert.h>

#define MCP3564_SLAVE_ADDRESS               0x13

#define MCP3564_COMMAND_WRITE               0x02
#define MCP3564_COMMAND_READ                0x03

static uint8_t spi_busy = 0;

static uint16_t spi_write_buffer;
static uint8_t spi_write_length;

static uint8_t *spi_read_buffer;
static uint8_t *spi_read_buffer_end;

static uint8_t spi_in_state = 0;

static enum
{
  SPI_STATE_IDLE = 0,
  SPI_STATE_READ,
  SPI_STATE_WRITE,
  SPI_STATE_FINISHED,
} spi_send_state;

static void mcp41010_spi_cs_on()
{
  DP_CS = 0;
}

static void mcp41010_spi_cs_off()
{
  DP_CS = 1;
}

void mcp41010_hw_turn_off()
{
  T2CONbits.TON = 0;
}

void mcp41010_hw_turn_on()
{
  T2CONbits.TON = 1; // Turn on timer for clock generation
}

uint8_t mcp41010_hw_ready()
{
  return (!spi_busy);
}

void mcp41010_hw_write_data(uint32_t data)
{
  uint32_t i;
  uint8_t data_8;
  
  data_8 = data;
  spi_busy = 0;
  
  SPI2CONbits.MODE16 = 1;         //  SPI_MODE16_ON
  SPI2CONbits.MODE32 = 0;         //  SPI_MODE32_OFF
  
  mcp41010_spi_cs_on();
  
  spi_write_buffer = (MCP3564_SLAVE_ADDRESS << 8) | data_8;
  
  i = SPI2BUF;
  SPI2BUF = spi_write_buffer;
  while(!SPI2STATbits.SPIRBF);

  mcp41010_spi_cs_off();
}