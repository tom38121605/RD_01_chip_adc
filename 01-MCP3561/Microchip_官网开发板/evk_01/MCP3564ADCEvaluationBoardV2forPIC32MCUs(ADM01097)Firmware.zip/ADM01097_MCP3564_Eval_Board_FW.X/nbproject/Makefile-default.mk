#
# Generated Makefile - do not edit!
#
# Edit the Makefile in the project folder instead (../Makefile). Each target
# has a -pre and a -post target defined where you can add customized code.
#
# This makefile implements configuration specific macros and targets.


# Include project Makefile
ifeq "${IGNORE_LOCAL}" "TRUE"
# do not include local makefile. User is passing all local related variables already
else
include Makefile
# Include makefile containing local settings
ifeq "$(wildcard nbproject/Makefile-local-default.mk)" "nbproject/Makefile-local-default.mk"
include nbproject/Makefile-local-default.mk
endif
endif

# Environment
MKDIR=gnumkdir -p
RM=rm -f 
MV=mv 
CP=cp 

# Macros
CND_CONF=default
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
IMAGE_TYPE=debug
OUTPUT_SUFFIX=elf
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
else
IMAGE_TYPE=production
OUTPUT_SUFFIX=hex
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
endif

ifeq ($(COMPARE_BUILD), true)
COMPARISON_BUILD=-mafrlcsj
else
COMPARISON_BUILD=
endif

ifdef SUB_IMAGE_ADDRESS

else
SUB_IMAGE_ADDRESS_COMMAND=
endif

# Object Directory
OBJECTDIR=build/${CND_CONF}/${IMAGE_TYPE}

# Distribution Directory
DISTDIR=dist/${CND_CONF}/${IMAGE_TYPE}

# Source Files Quoted if spaced
SOURCEFILES_QUOTED_IF_SPACED=sources/app/gui/gui.c sources/app/interrupts.c sources/app/app.c sources/drivers/core/core.c sources/drivers/io/io.c sources/drivers/io/io_hardware.c sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c sources/drivers/mcp3564/mcp3564.c sources/drivers/mcp3564/mcp3564_hardware.c sources/mcp41010.c sources/mcp41010_hardware.c sources/drivers/uart_buffer/uart_buffer.c sources/drivers/uart_buffer/uart_buffer_hardware.c sources/drivers/usb_vcp/mla_usb/usb_device.c sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c sources/drivers/usb_vcp/mla_usb/usb_descriptors.c sources/drivers/usb_vcp/usb_vcp.c sources/drivers/bsp.c sources/drivers/bsp_i2c.c sources/drivers/bsp_assert.c sources/main.c

# Object Files Quoted if spaced
OBJECTFILES_QUOTED_IF_SPACED=${OBJECTDIR}/sources/app/gui/gui.o ${OBJECTDIR}/sources/app/interrupts.o ${OBJECTDIR}/sources/app/app.o ${OBJECTDIR}/sources/drivers/core/core.o ${OBJECTDIR}/sources/drivers/io/io.o ${OBJECTDIR}/sources/drivers/io/io_hardware.o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o ${OBJECTDIR}/sources/mcp41010.o ${OBJECTDIR}/sources/mcp41010_hardware.o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o ${OBJECTDIR}/sources/drivers/bsp.o ${OBJECTDIR}/sources/drivers/bsp_i2c.o ${OBJECTDIR}/sources/drivers/bsp_assert.o ${OBJECTDIR}/sources/main.o
POSSIBLE_DEPFILES=${OBJECTDIR}/sources/app/gui/gui.o.d ${OBJECTDIR}/sources/app/interrupts.o.d ${OBJECTDIR}/sources/app/app.o.d ${OBJECTDIR}/sources/drivers/core/core.o.d ${OBJECTDIR}/sources/drivers/io/io.o.d ${OBJECTDIR}/sources/drivers/io/io_hardware.o.d ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d ${OBJECTDIR}/sources/mcp41010.o.d ${OBJECTDIR}/sources/mcp41010_hardware.o.d ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d ${OBJECTDIR}/sources/drivers/bsp.o.d ${OBJECTDIR}/sources/drivers/bsp_i2c.o.d ${OBJECTDIR}/sources/drivers/bsp_assert.o.d ${OBJECTDIR}/sources/main.o.d

# Object Files
OBJECTFILES=${OBJECTDIR}/sources/app/gui/gui.o ${OBJECTDIR}/sources/app/interrupts.o ${OBJECTDIR}/sources/app/app.o ${OBJECTDIR}/sources/drivers/core/core.o ${OBJECTDIR}/sources/drivers/io/io.o ${OBJECTDIR}/sources/drivers/io/io_hardware.o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o ${OBJECTDIR}/sources/mcp41010.o ${OBJECTDIR}/sources/mcp41010_hardware.o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o ${OBJECTDIR}/sources/drivers/bsp.o ${OBJECTDIR}/sources/drivers/bsp_i2c.o ${OBJECTDIR}/sources/drivers/bsp_assert.o ${OBJECTDIR}/sources/main.o

# Source Files
SOURCEFILES=sources/app/gui/gui.c sources/app/interrupts.c sources/app/app.c sources/drivers/core/core.c sources/drivers/io/io.c sources/drivers/io/io_hardware.c sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c sources/drivers/mcp3564/mcp3564.c sources/drivers/mcp3564/mcp3564_hardware.c sources/mcp41010.c sources/mcp41010_hardware.c sources/drivers/uart_buffer/uart_buffer.c sources/drivers/uart_buffer/uart_buffer_hardware.c sources/drivers/usb_vcp/mla_usb/usb_device.c sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c sources/drivers/usb_vcp/mla_usb/usb_descriptors.c sources/drivers/usb_vcp/usb_vcp.c sources/drivers/bsp.c sources/drivers/bsp_i2c.c sources/drivers/bsp_assert.c sources/main.c



CFLAGS=
ASFLAGS=
LDLIBSOPTIONS=

############# Tool locations ##########################################
# If you copy a project from one host to another, the path where the  #
# compiler is installed may be different.                             #
# If you open this project with MPLAB X in the new host, this         #
# makefile will be regenerated and the paths will be corrected.       #
#######################################################################
# fixDeps replaces a bunch of sed/cat/printf statements that slow down the build
FIXDEPS=fixDeps

.build-conf:  ${BUILD_SUBPROJECTS}
ifneq ($(INFORMATION_MESSAGE), )
	@echo $(INFORMATION_MESSAGE)
endif
	${MAKE}  -f nbproject/Makefile-default.mk dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}

MP_PROCESSOR_OPTION=32MX795F512L
MP_LINKER_FILE_OPTION=
# ------------------------------------------------------------------------------------
# Rules for buildStep: assemble
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assembleWithPreprocess
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: compile
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${OBJECTDIR}/sources/app/gui/gui.o: sources/app/gui/gui.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app/gui" 
	@${RM} ${OBJECTDIR}/sources/app/gui/gui.o.d 
	@${RM} ${OBJECTDIR}/sources/app/gui/gui.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/gui/gui.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/gui/gui.o.d" -o ${OBJECTDIR}/sources/app/gui/gui.o sources/app/gui/gui.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/app/interrupts.o: sources/app/interrupts.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app" 
	@${RM} ${OBJECTDIR}/sources/app/interrupts.o.d 
	@${RM} ${OBJECTDIR}/sources/app/interrupts.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/interrupts.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/interrupts.o.d" -o ${OBJECTDIR}/sources/app/interrupts.o sources/app/interrupts.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/app/app.o: sources/app/app.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app" 
	@${RM} ${OBJECTDIR}/sources/app/app.o.d 
	@${RM} ${OBJECTDIR}/sources/app/app.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/app.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/app.o.d" -o ${OBJECTDIR}/sources/app/app.o sources/app/app.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/core/core.o: sources/drivers/core/core.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/core" 
	@${RM} ${OBJECTDIR}/sources/drivers/core/core.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/core/core.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/core/core.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/core/core.o.d" -o ${OBJECTDIR}/sources/drivers/core/core.o sources/drivers/core/core.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/io/io.o: sources/drivers/io/io.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/io" 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/io/io.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/io/io.o.d" -o ${OBJECTDIR}/sources/drivers/io/io.o sources/drivers/io/io.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/io/io_hardware.o: sources/drivers/io/io_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/io" 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/io/io_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/io/io_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/io/io_hardware.o sources/drivers/io/io_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o: sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz" 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d" -o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o: sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz" 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o: sources/drivers/mcp3564/mcp3564.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/mcp3564" 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d" -o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o sources/drivers/mcp3564/mcp3564.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o: sources/drivers/mcp3564/mcp3564_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/mcp3564" 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o sources/drivers/mcp3564/mcp3564_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/mcp41010.o: sources/mcp41010.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/mcp41010.o.d 
	@${RM} ${OBJECTDIR}/sources/mcp41010.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/mcp41010.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/mcp41010.o.d" -o ${OBJECTDIR}/sources/mcp41010.o sources/mcp41010.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/mcp41010_hardware.o: sources/mcp41010_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/mcp41010_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/mcp41010_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/mcp41010_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/mcp41010_hardware.o.d" -o ${OBJECTDIR}/sources/mcp41010_hardware.o sources/mcp41010_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o: sources/drivers/uart_buffer/uart_buffer.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/uart_buffer" 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d" -o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o sources/drivers/uart_buffer/uart_buffer.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o: sources/drivers/uart_buffer/uart_buffer_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/uart_buffer" 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o sources/drivers/uart_buffer/uart_buffer_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o: sources/drivers/usb_vcp/mla_usb/usb_device.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o sources/drivers/usb_vcp/mla_usb/usb_device.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o: sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o: sources/drivers/usb_vcp/mla_usb/usb_descriptors.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o sources/drivers/usb_vcp/mla_usb/usb_descriptors.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o: sources/drivers/usb_vcp/usb_vcp.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o sources/drivers/usb_vcp/usb_vcp.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp.o: sources/drivers/bsp.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp.o.d" -o ${OBJECTDIR}/sources/drivers/bsp.o sources/drivers/bsp.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp_i2c.o: sources/drivers/bsp_i2c.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_i2c.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_i2c.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp_i2c.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp_i2c.o.d" -o ${OBJECTDIR}/sources/drivers/bsp_i2c.o sources/drivers/bsp_i2c.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp_assert.o: sources/drivers/bsp_assert.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_assert.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_assert.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp_assert.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp_assert.o.d" -o ${OBJECTDIR}/sources/drivers/bsp_assert.o sources/drivers/bsp_assert.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/main.o: sources/main.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/main.o.d 
	@${RM} ${OBJECTDIR}/sources/main.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/main.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG -D__MPLAB_DEBUGGER_ICD3=1  -fframe-base-loclist  -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/main.o.d" -o ${OBJECTDIR}/sources/main.o sources/main.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
else
${OBJECTDIR}/sources/app/gui/gui.o: sources/app/gui/gui.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app/gui" 
	@${RM} ${OBJECTDIR}/sources/app/gui/gui.o.d 
	@${RM} ${OBJECTDIR}/sources/app/gui/gui.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/gui/gui.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/gui/gui.o.d" -o ${OBJECTDIR}/sources/app/gui/gui.o sources/app/gui/gui.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/app/interrupts.o: sources/app/interrupts.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app" 
	@${RM} ${OBJECTDIR}/sources/app/interrupts.o.d 
	@${RM} ${OBJECTDIR}/sources/app/interrupts.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/interrupts.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/interrupts.o.d" -o ${OBJECTDIR}/sources/app/interrupts.o sources/app/interrupts.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/app/app.o: sources/app/app.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/app" 
	@${RM} ${OBJECTDIR}/sources/app/app.o.d 
	@${RM} ${OBJECTDIR}/sources/app/app.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/app/app.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/app/app.o.d" -o ${OBJECTDIR}/sources/app/app.o sources/app/app.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/core/core.o: sources/drivers/core/core.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/core" 
	@${RM} ${OBJECTDIR}/sources/drivers/core/core.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/core/core.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/core/core.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/core/core.o.d" -o ${OBJECTDIR}/sources/drivers/core/core.o sources/drivers/core/core.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/io/io.o: sources/drivers/io/io.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/io" 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/io/io.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/io/io.o.d" -o ${OBJECTDIR}/sources/drivers/io/io.o sources/drivers/io/io.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/io/io_hardware.o: sources/drivers/io/io_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/io" 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/io/io_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/io/io_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/io/io_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/io/io_hardware.o sources/drivers/io/io_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o: sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz" 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o.d" -o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz.o sources/drivers/lcd_c0216ciz/lcd_c0216ciz.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o: sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz" 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.o sources/drivers/lcd_c0216ciz/lcd_c0216ciz_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o: sources/drivers/mcp3564/mcp3564.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/mcp3564" 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o.d" -o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564.o sources/drivers/mcp3564/mcp3564.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o: sources/drivers/mcp3564/mcp3564_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/mcp3564" 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/mcp3564/mcp3564_hardware.o sources/drivers/mcp3564/mcp3564_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/mcp41010.o: sources/mcp41010.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/mcp41010.o.d 
	@${RM} ${OBJECTDIR}/sources/mcp41010.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/mcp41010.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/mcp41010.o.d" -o ${OBJECTDIR}/sources/mcp41010.o sources/mcp41010.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/mcp41010_hardware.o: sources/mcp41010_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/mcp41010_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/mcp41010_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/mcp41010_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/mcp41010_hardware.o.d" -o ${OBJECTDIR}/sources/mcp41010_hardware.o sources/mcp41010_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o: sources/drivers/uart_buffer/uart_buffer.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/uart_buffer" 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o.d" -o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer.o sources/drivers/uart_buffer/uart_buffer.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o: sources/drivers/uart_buffer/uart_buffer_hardware.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/uart_buffer" 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o.d" -o ${OBJECTDIR}/sources/drivers/uart_buffer/uart_buffer_hardware.o sources/drivers/uart_buffer/uart_buffer_hardware.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o: sources/drivers/usb_vcp/mla_usb/usb_device.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_device.o sources/drivers/usb_vcp/mla_usb/usb_device.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o: sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_function_cdc.o sources/drivers/usb_vcp/mla_usb/usb_function_cdc.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o: sources/drivers/usb_vcp/mla_usb/usb_descriptors.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/mla_usb/usb_descriptors.o sources/drivers/usb_vcp/mla_usb/usb_descriptors.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o: sources/drivers/usb_vcp/usb_vcp.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers/usb_vcp" 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o.d" -o ${OBJECTDIR}/sources/drivers/usb_vcp/usb_vcp.o sources/drivers/usb_vcp/usb_vcp.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp.o: sources/drivers/bsp.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp.o.d" -o ${OBJECTDIR}/sources/drivers/bsp.o sources/drivers/bsp.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp_i2c.o: sources/drivers/bsp_i2c.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_i2c.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_i2c.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp_i2c.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp_i2c.o.d" -o ${OBJECTDIR}/sources/drivers/bsp_i2c.o sources/drivers/bsp_i2c.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/drivers/bsp_assert.o: sources/drivers/bsp_assert.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources/drivers" 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_assert.o.d 
	@${RM} ${OBJECTDIR}/sources/drivers/bsp_assert.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/drivers/bsp_assert.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/drivers/bsp_assert.o.d" -o ${OBJECTDIR}/sources/drivers/bsp_assert.o sources/drivers/bsp_assert.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
${OBJECTDIR}/sources/main.o: sources/main.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} "${OBJECTDIR}/sources" 
	@${RM} ${OBJECTDIR}/sources/main.o.d 
	@${RM} ${OBJECTDIR}/sources/main.o 
	@${FIXDEPS} "${OBJECTDIR}/sources/main.o.d" $(SILENT) -rsi ${MP_CC_DIR}../  -c ${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -D_SUPPRESS_PLIB_WARNING -Dself_power=0 -DUSB_BUS_SENSE=0 -I"sources/app" -I"sources/drivers" -I"sources/drivers/usb_vcp/mla_usb" -MMD -MF "${OBJECTDIR}/sources/main.o.d" -o ${OBJECTDIR}/sources/main.o sources/main.c    -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD) 
	
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: compileCPP
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: link
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk    
	@${MKDIR} dist/${CND_CONF}/${IMAGE_TYPE} 
	${MP_CC} $(MP_EXTRA_LD_PRE) -g -mdebugger -D__MPLAB_DEBUGGER_ICD3=1 -mprocessor=$(MP_PROCESSOR_OPTION)  -o dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX} ${OBJECTFILES_QUOTED_IF_SPACED}          -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD)   -mreserve=data@0x0:0x1FC -mreserve=boot@0x1FC02000:0x1FC02FEF -mreserve=boot@0x1FC02000:0x1FC024FF  -Wl,--defsym=__MPLAB_BUILD=1$(MP_EXTRA_LD_POST)$(MP_LINKER_FILE_OPTION),--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,-D=__DEBUG_D,--defsym=__MPLAB_DEBUGGER_ICD3=1,--no-code-in-dinit,--no-dinit-in-serial-mem,-Map="${DISTDIR}/${PROJECTNAME}.${IMAGE_TYPE}.map",--memorysummary,dist/${CND_CONF}/${IMAGE_TYPE}/memoryfile.xml
	
else
dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk   
	@${MKDIR} dist/${CND_CONF}/${IMAGE_TYPE} 
	${MP_CC} $(MP_EXTRA_LD_PRE)  -mprocessor=$(MP_PROCESSOR_OPTION)  -o dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX} ${OBJECTFILES_QUOTED_IF_SPACED}          -DXPRJ_default=$(CND_CONF)  -legacy-libc  $(COMPARISON_BUILD)  -Wl,--defsym=__MPLAB_BUILD=1$(MP_EXTRA_LD_POST)$(MP_LINKER_FILE_OPTION),--no-code-in-dinit,--no-dinit-in-serial-mem,-Map="${DISTDIR}/${PROJECTNAME}.${IMAGE_TYPE}.map",--memorysummary,dist/${CND_CONF}/${IMAGE_TYPE}/memoryfile.xml
	${MP_CC_DIR}\\xc32-bin2hex dist/${CND_CONF}/${IMAGE_TYPE}/ADM01097_MCP3564_Eval_Board_FW.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX} 
endif


# Subprojects
.build-subprojects:


# Subprojects
.clean-subprojects:

# Clean Targets
.clean-conf: ${CLEAN_SUBPROJECTS}
	${RM} -r build/default
	${RM} -r dist/default

# Enable dependency checking
.dep.inc: .depcheck-impl

DEPFILES=$(shell mplabwildcard ${POSSIBLE_DEPFILES})
ifneq (${DEPFILES},)
include ${DEPFILES}
endif
