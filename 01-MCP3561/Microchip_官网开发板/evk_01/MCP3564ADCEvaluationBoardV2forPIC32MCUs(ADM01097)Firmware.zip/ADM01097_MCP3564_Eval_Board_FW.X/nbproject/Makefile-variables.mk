#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=ADM01097_MCP3564_Eval_Board_FW.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/ADM01097_MCP3564_Eval_Board_FW.X.production.hex
CND_PACKAGE_DIR_default=${CND_DISTDIR}/default/package
CND_PACKAGE_NAME_default=adm01097mcp3564evalboardfw.x.tar
CND_PACKAGE_PATH_default=${CND_DISTDIR}/default/package/adm01097mcp3564evalboardfw.x.tar
